#include "dialog.h"
#include &lt;QApplication&gt;

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Dialog w;
    w.setWindowTitle("Temperature Sensor Reading");
    w.setFixedSize(650,550);
    w.show();

    return a.exec();
}
