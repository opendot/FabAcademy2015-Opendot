#include "dialog.h"
#include "ui_dialog.h"
#include &lt;QSerialPort&gt;
#include &lt;QSerialPortInfo&gt;
#include &lt;string&gt;
#include &lt;QDebug&gt;
#include &lt;QMessageBox&gt;



Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui-&gt;setupUi(this);
    ui-&gt;temp_lcdNumber-&gt;display("-------");
    ui-&gt;temp_lcdNumber_2-&gt;display("-------");
    ui-&gt;temp_lcdNumber_3-&gt;display("-------");
    arduino = new QSerialPort(this);
    serialBuffer = "";
    parsed_data1 = "";
    parsed_data2 = "";
    parsed_data3 = "";
    moisture_value = 0.0;
    temperature_value = 0.0;
    humidity_value = 0.0;

    /*
     *  Testing code, prints the description, vendor id, and product id of all ports.
     *  Used it to determine the values for the arduino uno.
     *
     *
    qDebug() &lt;&lt; "Number of ports: " &lt;&lt; QSerialPortInfo::availablePorts().length() &lt;&lt; "\n";
    foreach(const QSerialPortInfo &serialPortInfo, QSerialPortInfo::availablePorts()){
        qDebug() &lt;&lt; "Description: " &lt;&lt; serialPortInfo.description() &lt;&lt; "\n";
        qDebug() &lt;&lt; "Has vendor id?: " &lt;&lt; serialPortInfo.hasVendorIdentifier() &lt;&lt; "\n";
        qDebug() &lt;&lt; "Vendor ID: " &lt;&lt; serialPortInfo.vendorIdentifier() &lt;&lt; "\n";
        qDebug() &lt;&lt; "Has product id?: " &lt;&lt; serialPortInfo.hasProductIdentifier() &lt;&lt; "\n";
        qDebug() &lt;&lt; "Product ID: " &lt;&lt; serialPortInfo.productIdentifier() &lt;&lt; "\n";
    }

*/

    /*
     *   Identify the port the arduino uno is on.
     */
    bool arduino_is_available = false;
    QString arduino_uno_port_name;
    //
    //  For each available serial port
    foreach(const QSerialPortInfo &serialPortInfo, QSerialPortInfo::availablePorts()){
        //  check if the serialport has both a product identifier and a vendor identifier
        if(serialPortInfo.hasProductIdentifier() && serialPortInfo.hasVendorIdentifier()){
            //  check if the product ID and the vendor ID match those of the arduino uno
            if((serialPortInfo.productIdentifier() == arduino_uno_product_id)
                    && (serialPortInfo.vendorIdentifier() == arduino_uno_vendor_id)){
                arduino_is_available = true; //    arduino uno is available on this port
                arduino_uno_port_name = serialPortInfo.portName();
            }
        }
    }

    /*
     *  Open and configure the arduino port if available
     */
    if(arduino_is_available){
        qDebug() &lt;&lt; "Found the arduino port...\n";
        arduino-&gt;setPortName(arduino_uno_port_name);
        arduino-&gt;open(QSerialPort::ReadOnly);
        arduino-&gt;setBaudRate(QSerialPort::Baud9600);
        arduino-&gt;setDataBits(QSerialPort::Data8);
        arduino-&gt;setFlowControl(QSerialPort::NoFlowControl);
        arduino-&gt;setParity(QSerialPort::NoParity);
        arduino-&gt;setStopBits(QSerialPort::OneStop);
        QObject::connect(arduino, SIGNAL(readyRead()), this, SLOT(readSerial()));

    }else{
        qDebug() &lt;&lt; "Couldn't find the correct port for the arduino.\n";
        QMessageBox::information(this, "Serial Port Error", "Couldn't open serial port to arduino.");
    }
}

Dialog::~Dialog()
{
    if(arduino-&gt;isOpen()){
        arduino-&gt;close(); //    Close the serial port if it's open.
    }
    delete ui;
}

void Dialog::readSerial()
{
    /*
     * readyRead() doesn't guarantee that the entire message will be received all at once.
     * The message can arrive split into parts.  Need to buffer the serial data and then parse for the temperature value.
     *
     */
qDebug() &lt;&lt; "TEST";
    QStringList buffer_split = serialBuffer.split(","); //  split the serialBuffer string, parsing with ',' as the separator

    //  Check to see if there less than 3 tokens in buffer_split.
    //  If there are at least 3 then this means there were 2 commas,
    //  means there is a parsed temperature value as the second token (between 2 commas)
    if(buffer_split.length() &lt; 7){
        // no parsed value yet so continue accumulating bytes from serial in the buffer.
        serialData = arduino-&gt;readAll();
        serialBuffer = serialBuffer + QString::fromStdString(serialData.toStdString());
        serialData.clear();
    }else {
        // the second element of buffer_split is parsed correctly, update the temperature value on temp_lcdNumber
       /*Original section
        serialBuffer = "";
        qDebug() &lt;&lt; buffer_split &lt;&lt; "\n";
        parsed_data = buffer_split[1];
        temperature_value = (9/5.0) * (parsed_data.toDouble()) + 32; // convert to fahrenheit
        qDebug() &lt;&lt; "Temperature: " &lt;&lt; temperature_value &lt;&lt; "\n";
        parsed_data = QString::number(temperature_value, 'g', 4); // format precision of temperature_value to 4 digits or fewer
        Dialog::updateTemperature(parsed_data);*/

        //new section
        serialBuffer = "";

        qDebug() &lt;&lt; buffer_split &lt;&lt; "\n";

        parsed_data1 = buffer_split[0];
        parsed_data2 = buffer_split[1];
        parsed_data3 = buffer_split[2];
        moisture_value = parsed_data1.toDouble();
        temperature_value = parsed_data2.toDouble();
        humidity_value = parsed_data3.toDouble();
        qDebug() &lt;&lt; "Moisture: " &lt;&lt; moisture_value &lt;&lt; "\n";
        qDebug() &lt;&lt; "Temperature: " &lt;&lt; temperature_value &lt;&lt; "\n";
        qDebug() &lt;&lt; "Humidity: " &lt;&lt; humidity_value &lt;&lt; "\n";
        parsed_data1 = QString::number(moisture_value, 'g', 4); // format precision of value to 4 digits or fewer
        parsed_data2 = QString::number(temperature_value, 'g', 4);
        parsed_data3 = QString::number(humidity_value, 'g', 4);

        Dialog::updateMoisture(moisture_value);
        Dialog::updateTemperature(temperature_value);
        Dialog::updateHumidity(humidity_value);

        /*Dialog::updateMoisture(parsed_data1);
        Dialog::updateTemperature(parsed_data2);
        Dialog::updateHumidity(parsed_data3);*/



    }

}


void Dialog::updateTemperature(double sensor_reading)
{
    //  update the value displayed on the lcdNumber
    ui-&gt;temp_lcdNumber_2-&gt;display(sensor_reading);
}

void Dialog::updateMoisture(double sensor_reading)
{
    //  update the value displayed on the lcdNumber
    ui-&gt;temp_lcdNumber-&gt;display(sensor_reading);
}

void Dialog::updateHumidity(double sensor_reading)
{
    //  update the value displayed on the lcdNumber
    ui-&gt;temp_lcdNumber_3-&gt;display(sensor_reading);
}


/*void Dialog::updateTemperature(QString sensor_reading)
{
    //  update the value displayed on the lcdNumber
    ui-&gt;temp_lcdNumber_2-&gt;display(sensor_reading);
}

void Dialog::updateMoisture(QString sensor_reading)
{
    //  update the value displayed on the lcdNumber
    ui-&gt;temp_lcdNumber-&gt;display(sensor_reading);
}

void Dialog::updateHumidity(QString sensor_reading)
{
    //  update the value displayed on the lcdNumber
    ui-&gt;temp_lcdNumber_3-&gt;display(sensor_reading);
}
*/
