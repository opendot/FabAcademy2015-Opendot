#!/usr/local/bin/python

import os
import xml.dom.minidom
from fabacademy import parse_path
import sys
   

if len(sys.argv) == 1:
    sys.exit("svg2path.py FILENAME [x y ]")
if not os.path.exists(sys.argv[1]):
    sys.exit("Input file does not exist")
x, y = None, None
if len(sys.argv) >= 3:
    x = float(sys.argv[2])
    y = float(sys.argv[3])
    print "eeeee"

svg_file = xml.dom.minidom.parse(sys.argv[1])
svg = svg_file.getElementsByTagName('svg')[0]

raw_width = float(svg.getAttribute('width'))
raw_height = float(svg.getAttribute('height'))

print x
if (not(x,y==None) and  raw_width>x and raw_height>y):
    sys.exit("eh?")
#width_ratio = x and (x / raw_width) or 1
#height_ratio = y and (y / raw_height) or 1

pathCommands=[]
elements = svg.getElementsByTagName('g')
print "Groups #"+str(elements.__len__())
for e in elements:
    paths = []
    if e.nodeName == 'g':
        for path in e.getElementsByTagName('path'):
            #print parse_path.path.parseString(path.getAttribute('d'))
            pathCommands = parse_path.get_path_commands(path.getAttribute('d'))
            print pathCommands
for command in pathCommands:
    print  command
    

