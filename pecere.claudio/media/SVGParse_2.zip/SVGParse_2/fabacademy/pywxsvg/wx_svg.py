# wx_svg.py
# Copyright Max Kolosov 2009 maxkolosov@inbox.ru
# http://saxi.nm.ru/
# BSD license

this_version = '0.3'

import os, sys, wx

from svg_parser import parse_xml_data
from arc import elliptical_arc_to

logo = '''<?xml version="1.0" encoding="UTF-8"?>
<svg width="550" height="250">
<g transform="scale(10,10)">
<text style="stroke:#00FF00; stroke-width:1; fill:#00FFFF; font-size:20; font-family:Arial; font-style:normal; font-weight:normal" x="0" y="0" >SVG</text>
</g>
</svg>'''

def print_error():
	exc, err, traceback = sys.exc_info()
	print exc, traceback.tb_frame.f_code.co_filename, 'ERROR ON LINE', traceback.tb_lineno, '\n', err
	del exc, err, traceback

def file_name_from_gzip_header(fileobj):
	'_read_gzip_header method of GzipFile class; from gzip.py module'
	result = ''
	fileobj.seek(0)
	magic = fileobj.read(2)
	if magic != '\037\213':
		return result
	method = ord( fileobj.read(1) )
	if method != 8:
		return result
	flag = ord( fileobj.read(1) )
	fileobj.read(6)
	if flag & 4:
		xlen = ord(fileobj.read(1))
		xlen = xlen + 256*ord(fileobj.read(1))
		fileobj.read(xlen)
	if flag & 8:
		while True:
			byte = fileobj.read(1)
			if not byte or byte == '\000':
				fileobj.seek(0)
				break
			else:
				result += byte
	return result

def func_draw_to_dc(dc, data):
	pass

def func_draw_to_gc(gc, data):
	defs_container = {}
	def get_brush(value):
		if 'url(#' in value:
			return defs_container.get(value.strip('url(#)'), wx.NullGraphicsBrush)
		else:
			try:
				return wx.Brush(value)
			except:
				return wx.NullBrush
	def draw_sequence(sequence):
		def translate(dx, dy):
			gc.Translate(dx, dy)
		def scale(xScale, yScale):
			gc.Scale(xScale, yScale)
		def rotate(angle):
			gc.Rotate(angle)
		def matrix(a, b, c, d, tx, ty):
			gc.SetTransform(gc.CreateMatrix(a, b, c, d, tx, ty))
		for element in sequence:
			gc.PushState()
			if element['svg_key'] == 'defs':
				draw_sequence(element['children'])
			elif element['svg_key'] == 'linearGradient':
				c1 = element['children'][0]['stop-color']
				c2 = element['children'][1]['stop-color']
				defs_container[element.get('id', 'error_id')] = gc.CreateLinearGradientBrush(element['x1'], element['y1'], element['x2'], element['y2'], c1, c2)
			elif element['svg_key'] == 'radialGradient':
				c1 = element['children'][0]['stop-color']
				c2 = element['children'][1]['stop-color']
				defs_container[element['id']] = gc.CreateRadialGradientBrush(element['cx'], element['cy'], element['fx'], element['fy'], element['r'], c1, c2)
			elif element['svg_key'] == 'text':
				if element.has_key('style'):
					style = element['style']
					if style.has_key('stroke'):
						graphics_pen = gc.CreatePen(wx.Pen(style['stroke'], style.get('stroke-width', 1.0)))
						gc.SetPen(graphics_pen)
					if style.has_key('fill'):
						gc.SetBrush(get_brush(style['fill']))
					if style.has_key('font-size') or style.has_key('font-family') or style.has_key('font-style') or style.has_key('font-weight'):
						default_font = wx.SystemSettings.GetFont(wx.SYS_DEFAULT_GUI_FONT)
						new_font = wx.Font(
							style.get('font-size', default_font.GetPointSize()),
							default_font.GetFamily(),
							style.get('font-style', default_font.GetStyle()),
							style.get('font-weight', default_font.GetWeight()),
							face = style.get('font-family', default_font.GetFaceName()))
						if style.has_key('stroke'):
							new_font = gc.CreateFont(new_font, style['stroke'])
						gc.SetFont(new_font)
				if element.has_key('transform'):
					try:
						eval(element['transform'])
					except:
						print_error()
				gc.DrawText(element['value'], element['x'], element['y'])
			elif element['svg_key'] == 'line':
				if element.has_key('style'):
					style = element['style']
					if style.has_key('stroke'):
						gc.SetPen(wx.Pen(style['stroke'], style.get('stroke-width', 1.0)))
					if style.has_key('fill'):
						gc.SetBrush(get_brush(style['fill']))
				elif element.has_key('stroke'):
					gc.SetPen(wx.Pen(element['stroke'], element.get('stroke-width', 1.0)))
				if element.has_key('transform'):
					try:
						eval(element['transform'])
					except:
						print_error()
				gc.StrokeLine(element['x1'], element['y1'], element['x2'], element['y2'])
			elif element['svg_key'] in ('polyline', 'polygon'):
				if element.has_key('style'):
					style = element['style']
					if style.has_key('stroke'):
						gc.SetPen(wx.Pen(style['stroke'], style.get('stroke-width', 1.0)))
					if style.has_key('fill'):
						gc.SetBrush(get_brush(style['fill']))
				elif element.has_key('stroke'):
					gc.SetPen(wx.Pen(element['stroke'], element.get('stroke-width', 1.0)))
				if element.has_key('transform'):
					try:
						eval(element['transform'])
					except:
						print_error()
				gc.StrokeLines(element['points'])
			elif element['svg_key'] == 'circle':
				if element.has_key('style'):
					style = element['style']
					if style.has_key('stroke'):
						gc.SetPen(wx.Pen(style['stroke'], style.get('stroke-width', 1.0)))
					if style.has_key('fill'):
						gc.SetBrush(get_brush(style['fill']))
				path = gc.CreatePath()
				path.AddCircle(element['cx'], element['cy'], element['r'])
				if element.has_key('transform'):
					try:
						eval(element['transform'])
					except:
						print_error()
				gc.DrawPath(path)
				#~ gc.DrawEllipse(element['cx']-element['r'], element['cy']-element['r'], element['r']*2, element['r']*2)
			elif element['svg_key'] == 'ellipse':
				if element.has_key('style'):
					style = element['style']
					if style.has_key('stroke'):
						gc.SetPen(wx.Pen(style['stroke'], style.get('stroke-width', 1.0)))
					if style.has_key('fill'):
						gc.SetBrush(get_brush(style['fill']))
				if element.has_key('transform'):
					try:
						eval(element['transform'])
					except:
						print_error()
				gc.DrawEllipse(element['cx'], element['cy'], element['rx'], element['ry'])
			elif element['svg_key'] == 'rect':
				if element.has_key('style'):
					style = element['style']
					if style.has_key('stroke'):
						gc.SetPen(wx.Pen(style['stroke'], style.get('stroke-width', 1.0)))
					if style.has_key('fill'):
						gc.SetBrush(get_brush(style['fill']))
				elif element.has_key('stroke'):
					gc.SetPen(wx.Pen(element['stroke'], element.get('stroke-width', 1.0)))
					if element.has_key('fill'):
						gc.SetBrush(get_brush(element['fill']))
				if element.has_key('transform'):
					try:
						eval(element['transform'])
					except:
						print_error()
				if element.has_key('rx'):
					gc.DrawRoundedRectangle(element['x'], element['y'], element['width'], element['height'], element['rx'])
				else:
					gc.DrawRectangle(element['x'], element['y'], element['width'], element['height'])
			elif element['svg_key'] == 'path':
				if element.has_key('style'):
					style = element['style']
					if style.has_key('stroke'):
						gc.SetPen(wx.Pen(style['stroke'], style.get('stroke-width', 1.0)))
					if style.has_key('fill'):
						gc.SetBrush(get_brush(style['fill']))
				path = gc.CreatePath()
				start_x, start_y = 0, 0
				cx, cy, cx2, cy2 = None, None, None, None
				for key, params in element['d']:
					x_current, y_current = path.GetCurrentPoint()
					if key == 'Z':
						path.CloseSubpath()
					if key == 'z':
						path.AddLineToPoint(start_x, start_y)
						path.CloseSubpath()
					elif key == 'A':
						for (rx, ry), axis_rotation, large_arc_flag, sweep_flag, (x, y) in params:
							for p in elliptical_arc_to(x_current, y_current, rx, ry, axis_rotation, large_arc_flag, sweep_flag, x, y):
								if len(p) == 2:
									path.AddLineToPoint(*p)
								elif len(p) == 6:
									path.AddCurveToPoint(*p)
					elif key == 'a':
						for (rx, ry), axis_rotation, large_arc_flag, sweep_flag, (x, y) in params:
							x, y = x_current + x, y_current + y
							for p in elliptical_arc_to(x_current, y_current, rx, ry, axis_rotation, large_arc_flag, sweep_flag, x, y):
								if len(p) == 2:
									path.AddLineToPoint(*p)
								elif len(p) == 6:
									path.AddCurveToPoint(*p)
					elif key == 'H':
						for x in params:
							path.AddLineToPoint(x, y_current)
					elif key == 'h':
						for x in params:
							path.AddLineToPoint(x_current + x, y_current)
					elif key == 'V':
						for y in params:
							path.AddLineToPoint(x_current, y)
					elif key == 'v':
						for y in params:
							path.AddLineToPoint(x_current, y_current + y)
					elif key == 'M':
						for x, y in params:
							path.MoveToPoint(x, y)
							start_x, start_y = x, y
					elif key == 'm':
						for x, y in params:
							path.MoveToPoint(x_current + x, y_current + y)
							start_x, start_y = x_current + x, y_current + y
					elif key == 'L':
						for x, y in params:
							path.AddLineToPoint(x, y)
					elif key == 'l':
						for x, y in params:
							path.AddLineToPoint(x_current + x, y_current + y)
					elif key == 'C':
						for (cx1, cy1), (cx2, cy2), (x, y) in params:
							path.AddCurveToPoint(cx1, cy1, cx2, cy2, x, y)
					elif key == 'c':
						for (cx1, cy1), (cx2, cy2), (x, y) in params:
							cx2, cy2 = x_current + cx2, y_current + cy2
							path.AddCurveToPoint(x_current + cx1, y_current + cy1, cx2, cy2, x_current + x, y_current + y)
					elif key == 'S':
						if (cx2, cy2) == (None, None):
							cx1, cy1 = x_current, y_current
						else:
							cx1, cy1 = x_current * 2 - cx2, y_current * 2 - cy2
						for (cx2, cy2), (x, y) in params:
							path.AddCurveToPoint(cx1, cy1, cx2, cy2, x, y)
					elif key == 's':
						if (cx2, cy2) == (None, None):
							cx1, cy1 = x_current, y_current
						else:
							cx1, cy1 = x_current * 2 - cx2, y_current * 2 - cy2
						for (cx2, cy2), (x, y) in params:
							path.AddCurveToPoint(cx1, cy1, x_current + cx2, y_current + cy2, x_current + x, y_current + y)
					elif key == 'T':
						if (cx, cy) == (None, None):
							cx, cy = x_current, y_current
						else:
							cx, cy = x_current * 2 - cx, y_current * 2 - cy
						for (x, y) in params:
							path.AddQuadCurveToPoint(cx, cy, x, y)
					elif key == 't':
						if (cx, cy) == (None, None):
							cx, cy = x_current, y_current
						else:
							cx, cy = x_current * 2 - cx, y_current * 2 - cy
						for (x, y) in params:
							path.AddQuadCurveToPoint(cx, cy, x_current + x, y_current + y)
					elif key == 'Q':
						for (cx, cy), (x, y) in params:
							path.AddQuadCurveToPoint(cx, cy, x, y)
					elif key == 'q':
						for (cx, cy), (x, y) in params:
							path.AddQuadCurveToPoint(x_current + cx, y_current + cy, x_current + x, y_current + y)
				gc.DrawPath(path)
			elif element['svg_key'] == 'image':
				if os.path.isfile(element['href']):
					gc.DrawBitmap(wx.Bitmap(element['href']), element['x'], element['y'], element['width'], element['height'])
			elif element['svg_key'] == 'a':
				if element.has_key('style'):
					style = element['style']
					if style.has_key('stroke'):
						gc.SetPen(wx.Pen(style['stroke'], style.get('stroke-width', 1.0)))
					if style.has_key('fill'):
						gc.SetBrush(get_brush(style['fill']))
				if element.has_key('transform'):
					try:
						eval(element['transform'])
					except:
						print_error()
				draw_sequence(element['children'])
			elif element['svg_key'] == 'g':
				if element.has_key('style'):
					style = element['style']
					if style.has_key('stroke'):
						gc.SetPen(wx.Pen(style['stroke'], style.get('stroke-width', 1.0)))
					if style.has_key('fill'):
						gc.SetBrush(get_brush(style['fill']))
				if element.has_key('transform'):
					try:
						eval(element['transform'])
					except:
						print_error()
				draw_sequence(element['children'])
			gc.PopState()
	draw_sequence(data)

def func_draw(dc, data, scale_x = 1.0, scale_y = 1.0, use_cairo = True):
	GraphicsContext = wx.GraphicsContext
	if use_cairo:
		try:
			from wx.lib.graphics import GraphicsContext
		except:
			print_error()
	try:
		gc = GraphicsContext.Create(dc)
	except NotImplementedError:
		dc.SetUserScale(scale_x, scale_y)
		dc.SetFont(wx.SystemSettings.GetFont(wx.SYS_DEFAULT_GUI_FONT))
		func_draw_to_dc(dc, data)
	else:
		gc.Scale(scale_x, scale_y)
		gc.SetFont(wx.SystemSettings.GetFont(wx.SYS_DEFAULT_GUI_FONT))
		func_draw_to_gc(gc, data)

def svg_to_bitmap(data, size = (0, 0), use_alpha = True, alpha_for_buffer = wx.ALPHA_OPAQUE, use_cairo = True):
	scale_x, scale_y = 1.0, 1.0
	svg_data = parse_xml_data(data)
	width, height = svg_data['width'], svg_data['height']
	if size[0] > 0:
		if width > size[0]:
			scale_x = scale_x / (width / size[0])
		elif width < size[0]:
			scale_x = size[0] / width
		width = size[0]
	if size[1] > 0:
		if height > size[1]:
			scale_y = scale_y / (height / size[1])
		elif height < size[1]:
			scale_y = size[1] / height
		height = size[1]
	if use_alpha:
		try:
			buffer = wx.EmptyBitmapRGBA(width, height, alpha = alpha_for_buffer)
		except:
			print_error()
	else:
		buffer = wx.EmptyBitmap(width, height)
	dc = wx.BufferedDC(None, buffer)
	dc.Clear()
	func_draw(dc, svg_data['children'], scale_x, scale_y, use_cairo)
	return buffer

handler_types = [handler.Type for handler in wx.Image_GetHandlers()]
wx.BITMAP_TYPE_SVG = max(handler_types) + 1
wx.BITMAP_TYPE_SVGZ = wx.BITMAP_TYPE_SVG + 1

class svg_handler(wx.PyImageHandler):
	def __init__(self, *args, **kwargs):
		_name = kwargs.pop('name', 'svg_handler')
		_extension = kwargs.pop('extension', 'svg')
		_mime_type = kwargs.pop('mime_type', 'image/svg+xml')
		_type = kwargs.pop('type', wx.BITMAP_TYPE_SVG)

		wx.PyImageHandler.__init__(self, *args, **kwargs)
		self.SetName(_name)
		self.SetExtension(_extension)
		self.SetMimeType(_mime_type)
		self.SetType(_type)

	def DoCanRead(self, stream):
		return stream.CanRead()

	def LoadFile(self, image, stream, verbose = True, index = -1):
		result = False
		data, file_name = '', 'file.svg'
		if self.GetExtension() == 'svgz':
			import gzip
			from StringIO import StringIO
			data = gzip.GzipFile(fileobj = StringIO(stream.read())).read()
			file_name = file_name_from_gzip_header(stream)
		else:
			data = stream.read()
		temp_image = svg_to_bitmap(data, use_cairo = False).ConvertToImage()
		if temp_image.IsOk():
			result = image.Create(temp_image.GetWidth(), temp_image.GetHeight())
			image.SetData(temp_image.GetData())
			image.SetOption('data', data)
			image.SetOption('file_name', file_name)
		del temp_image
		return result

	def SaveFile(self, image, stream, verbose = True):
		result = image.IsOk() and image.HasOption('data')
		if result:
			if self.GetExtension() == 'svgz':
				import gzip
				file_name = 'file.svg'
				if image.HasOption('file_name'):
					file_name = image.GetOption('file_name')
				gzip_stream = gzip.GzipFile(file_name, 'w', fileobj = stream)
				gzip_stream.write(image.GetOption('data'))
				gzip_stream.close()
			else:
				stream.write(image.GetOption('data'))
		return result

	def GetImageCount(self, stream):
		return 1

wx.Image_AddHandler(svg_handler())
wx.Image_AddHandler(svg_handler(extension = 'svgz', type = wx.BITMAP_TYPE_SVGZ))

class svg_printout(wx.Printout):
	def __init__(self, *args, **kwargs):
		self.canvas = kwargs.pop('canvas', None)
		super(svg_printout, self).__init__(*args, **kwargs)
		self.pages = 0

	def OnBeginDocument(self, start, end):
		return super(svg_printout, self).OnBeginDocument(start, end)

	def OnEndDocument(self):
		super(svg_printout, self).OnEndDocument()

	def OnBeginPrinting(self):
		super(svg_printout, self).OnBeginPrinting()

	def OnEndPrinting(self):
		super(svg_printout, self).OnEndPrinting()

	def OnPreparePrinting(self):
		super(svg_printout, self).OnPreparePrinting()

	def HasPage(self, page):
		if page > 0 and page <= self.pages:
			return True
		else:
			return False

	def GetPageInfo(self):
		return (1, self.pages, 1, self.pages)

	def OnPrintPage(self, page):
		self.pages = 1
		dc = self.GetDC()
		#~ self.canvas.draw_to_dc(dc) # but "dc.DrawBitmap" more faster
		dc.DrawBitmap(self.canvas.buffer, 0, 0)
		return True

class svg_canvas(wx.ScrolledWindow):
	def __init__(self, *args, **kwargs):
		default_use_alpha = True
		# check use alpha for previous Windows XP platforms
		if sys.platform == 'win32':
			ver_ex = sys.getwindowsversion()
			if ver_ex[0] < 5 or ver_ex[0] == 5 and ver_ex[1] == 0:
				default_use_alpha = False

		data = kwargs.pop('data', '')
		self.file_name = kwargs.pop('file_name', '')
		self.use_cairo = kwargs.pop('use_cairo', True)
		self.use_alpha = kwargs.pop('use_alpha', default_use_alpha)
		self.alpha_for_buffer = kwargs.pop('alpha_for_buffer', wx.ALPHA_OPAQUE)

		super(svg_canvas, self).__init__(*args, **kwargs)

		self.scale_x = 1.0
		self.scale_y = 1.0
		self.scale_delta = 0.05

		self.svg_data = None
		if data != '':
			self.draw_data(data, False)
		elif os.path.isfile(self.file_name):
			import gzip
			try:
				self.draw_data(gzip.open(self.file_name, 'rb').read(), False)
			except:
				self.draw_data(open(self.file_name, 'rb').read(), False)
		else:
			self.buffer = wx.EmptyBitmap(0, 0)

		self.SetScrollRate(20, 20)

		self.Bind(wx.EVT_MOUSEWHEEL, self.event_mousewheel)
		self.Bind(wx.EVT_PAINT, self.event_paint)

	def draw_buffer(self):
		self.Freeze()
		wx.BeginBusyCursor()
		self.scale_x += self.svg_data['scale_x']
		self.scale_y += self.svg_data['scale_y']
		width, height = self.svg_data['viewBox'][2] * self.scale_x, self.svg_data['viewBox'][3] * self.scale_y
		self.SetVirtualSize((width, height))
		if self.use_alpha:
			try:
				self.buffer = wx.EmptyBitmapRGBA(width, height, alpha = self.alpha_for_buffer)
			except:
				print_error()
				self.buffer = wx.EmptyBitmap(width, height)
		else:
			self.buffer = wx.EmptyBitmap(width, height)
		dc = wx.BufferedDC(None, self.buffer, wx.BUFFER_VIRTUAL_AREA)
		dc.Clear()
		dc.SetDeviceOrigin(self.svg_data['origin_x'], self.svg_data['origin_y'])
		self.draw_to_dc(dc)
		wx.EndBusyCursor()
		self.Thaw()

	def draw_data(self, data, refresh = True):
		try:
			self.svg_data = parse_xml_data(data)
			if isinstance(self.svg_data, dict):
				self.reset_scale()
				self.draw_buffer()
				if refresh:
					self.Refresh()
		except:
			print_error()

	def draw_file(self, file_name):
		if os.path.isfile(file_name):
			import gzip
			self.file_name = file_name
			try:
				self.draw_data(gzip.open(self.file_name, 'rb').read())
			except:
				self.draw_data(open(self.file_name, 'rb').read())

	def reset_scale(self):
		self.scale_x = 1.0
		self.scale_y = 1.0

	def zoom_to_original_size(self):
		self.reset_scale()
		self.draw_buffer()
		self.Refresh()

	def event_mousewheel(self, event):
		old_x, old_y = self.scale_x, self.scale_y
		if event.GetWheelRotation() > 0:
			self.scale_x += self.scale_delta
			self.scale_y += self.scale_delta
		else:
			self.scale_x -= self.scale_delta
			self.scale_y -= self.scale_delta
			if self.scale_x < self.scale_delta:
				self.scale_x = self.scale_delta
			if self.scale_y < self.scale_delta:
				self.scale_y = self.scale_delta
		if (self.scale_x, self.scale_y) != (old_x, old_y):
			self.draw_buffer()

	def event_paint(self, event):
		dc = wx.BufferedPaintDC(self, self.buffer, wx.BUFFER_VIRTUAL_AREA)

	def draw_to_dc(self, dc):
		if len(self.svg_data['children']) > 0:
			func_draw(dc, self.svg_data['children'], self.scale_x, self.scale_y, self.use_cairo)

	def get_as_raster_graphics(self, return_as_wx_image = False, size = None):
		result = wx.NullBitmap
		if return_as_wx_image:
			result = self.buffer.ConvertToImage()
		if size is not None and return_as_wx_image:
			result.Rescale(size[0], size[1], wx.IMAGE_QUALITY_HIGH)
		elif size is not None and not return_as_wx_image:
			img = self.buffer.ConvertToImage()
			img.Rescale(size[0], size[1], wx.IMAGE_QUALITY_HIGH)
			result = img.ConvertToBitmap()
		else:
			result = self.buffer
		return result

	def save_raster_graphics_to_file(self, name_file = '', type_file = wx.BITMAP_TYPE_PNG):
		file_formats = (
						wx.BITMAP_TYPE_BMP,
						wx.BITMAP_TYPE_GIF,
						wx.BITMAP_TYPE_JPEG,
						wx.BITMAP_TYPE_PNG,
						wx.BITMAP_TYPE_PCX,
						wx.BITMAP_TYPE_PNM,
						wx.BITMAP_TYPE_TIF,
						wx.BITMAP_TYPE_TGA,
						wx.BITMAP_TYPE_XPM,
						wx.BITMAP_TYPE_ICO,
						wx.BITMAP_TYPE_CUR,
						wx.BITMAP_TYPE_ANI,
						wx.BITMAP_TYPE_ANY
						)
		wildcard = 'bmp (*.bmp)|*.bmp|'\
					'gif (*.gif)|*.gif|'\
					'jpg (*.jpg)|*.jpg|'\
					'png (*.png)|*.png|'\
					'pcx (*.pcx)|*.pcx|'\
					'pnm (*.pnm)|*.pnm|'\
					'tif (*.tif)|*.tif|'\
					'tga (*.tga)|*.tga|'\
					'xpm (*.xpm)|*.xpm|'\
					'ico (*.ico)|*.ico|'\
					'cur (*.cur)|*.cur|'\
					'ani (*.ani)|*.ani|'\
					'Any file format (*.*)|*.*'
		if name_file == '':
			name_file = self.file_name.replace('.svg', '')
		dlg = wx.FileDialog(self, _('Save raster graphics to file'), '',  name_file, wildcard, wx.SAVE|wx.CHANGE_DIR)
		if dlg.ShowModal() == wx.ID_OK:
			wx.BeginBusyCursor()
			try:
				self.buffer.SaveFile(dlg.GetPath(), file_formats[dlg.GetFilterIndex()])
			except:
				print_error()
			wx.EndBusyCursor()
		dlg.Destroy()

def test_svg_handler():
	load_file_name = 'test.svgz'
	save_file_name = 'test_new.svgz'
	if os.path.isfile(load_file_name):
		#~ image = wx.Image(load_file_name, wx.BITMAP_TYPE_SVG)
		image = wx.Image(load_file_name, wx.BITMAP_TYPE_SVGZ)
		if image.IsOk():
			#~ image.SetOption('file_name', load_file_name)
			image.SaveFile(save_file_name, wx.BITMAP_TYPE_SVGZ)
	else:
		from StringIO import StringIO
		load_file_name = 'svg.svg'
		image = wx.ImageFromStream(StringIO(logo), wx.BITMAP_TYPE_SVG)
		if image.IsOk():
			image.SetOption('file_name', load_file_name)
			image.SaveFile(save_file_name, wx.BITMAP_TYPE_SVGZ)

def main():
	from wx.lib.scrolledpanel import ScrolledPanel
	app = wx.PySimpleApp()

	test_svg_handler() # only after app is create

	frame = wx.Frame(None, wx.ID_ANY, 'wxPython SVG canvas ' + this_version)
	panel = ScrolledPanel(frame, wx.ID_ANY)
	sizer = wx.GridSizer(1, 1)
	canvas = svg_canvas(panel, data = logo, use_cairo = False)
	sizer.Add(canvas, 0, wx.EXPAND | wx.ALL)
	panel.SetSizer(sizer)
	panel.SetAutoLayout(1)
	panel.SetupScrolling()
	app.SetTopWindow(frame)
	frame.SetIcon(wx.IconFromBitmap(svg_to_bitmap(logo, (32, 32), use_cairo = False)))
	frame.SetSize(canvas.GetVirtualSize())
	frame.Show()
	app.MainLoop()

if __name__=='__main__':
	main()
