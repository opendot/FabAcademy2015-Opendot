# wx_svg_viewer.py
# Copyright Max Kolosov 2009 maxkolosov@inbox.ru
# http://saxi.nm.ru/
# BSD license

_version = '0.3'

import os, sys, wx

from wx.py import shell, version
from wx.html import HtmlHelpController
from wx.lib.scrolledpanel import ScrolledPanel
from wx.aui import AuiManager, AuiPaneInfo, AuiToolBar, \
AUI_TB_DEFAULT_STYLE, AUI_TB_VERTICAL, AUI_TB_OVERFLOW

from wx_svg import logo, svg_to_bitmap, svg_canvas, svg_printout

import gettext
_ = gettext.gettext

from locale import getdefaultlocale, setlocale, LC_ALL
setlocale(LC_ALL, '')

default_fullscreen_style = wx.FULLSCREEN_NOSTATUSBAR | wx.FULLSCREEN_NOBORDER | wx.FULLSCREEN_NOCAPTION

xpm_clear = '''16 16 4 1
 	c None
.	c #246AC1
@	c #FCB953
#	c #0C007C
                
           ..   
         ....   
       ......   
     @@@@...    
   @@@@@@@..    
  @@@@@@@@@.    
 #@@@@@@@@@@### 
####@@@@@@@@####
##   @@@@@@   ##
##            ##
##            ##
##            ##
##            ##
################
 ############## '''
log_xpm = '''16 16 4 1
  c None
. c #8000C0
o c #E00080
X c #00FF00
                
                
                
 .     XX  ooo  
 .    X  X o  o 
 .    X  X o    
 .    X  X o    
 .    X  X o    
 .    X  X o    
 .    X  X o o  
 .    X  X o  o 
 .    X  X o  o 
 ....  XX  ooo  
                
                
                '''
xpm_fullscreen = '''28 28 32 1
q c None
` c #0442a4
. c #0997fc
# c #b52010
a c #d49166
b c #f9c96f
c c #885738
d c #f6b05d
e c #e5562a
f c #0464ca
g c #f29348
h c #4e372e
i c #da6e4c
j c #faa049
k c #847ec4
l c #b67a4e
m c #714c35
n c #fcee8c
o c #7c7ec4
p c #cf3f20
r c #bc621c
s c #0455bb
t c #0480e6
u c #fcfcf4
v c #f87838
w c #345aac
x c #5f4033
y c #fcde9c
z c #95694e
A c #fcbe61
B c #f8db82
C c #e9612c
`s````qqqqqqqqqqqqqqqq``````
`.t`wqqqqqqqqqqqqqqqqqqwfff`
`tffwqqqqqqqqqqqqqqqqqq`fff`
`fffswqqqqqqqqqqqqqqqq`ffsf`
`w`sff`oooooooooooook`ffsww`
`qq`fshvCvvvgvjjjjddd`fswqq`
qqqq`hivCvvvgjjjddAdAd`wqqqq
qqqqoicvvvggggjjdddAAAAoqqqq
qqqqoimCvvvgvjjjdAAbBBAoqqqq
qqqqozxrvvvggjjddAABuuBkqqqq
qqqqozxcvvgggjjjdAAyuuyoqqqq
qqqqocmmvvvggCvvvvdbBBAkqqqq
qqqqkcxxrvvCp#pppeeeCvCkqqqq
qqqqochxc#####pppepCeeCkqqqq
qqqqocxxmc####ppppepeeekqqqq
qqqqomxhxc##ppppeeeCCCCkqqqq
qqqqklhhxrvjgjgjggjAAggkqqqq
qqqqoahhhmlggggjgjjdAjjoqqqq
qqqqolchhxcgggggggjbBbjoqqqq
qqqqkalhhhclaaaagaAAnndoqqqq
qqqqo`ahhhmzaagaagaajb`oqqqq
qqqq```xhhhmaaaaaaddd`s`qqqq
`qq`t.s`mczzaaaaaaaa`w.t`qq`
```ftf`koooooookkoooo`tts```
`sfff`qqqqqqqqqqqqqqqq`ffsf`
`fff`qqqqqqqqqqqqqqqqqq`fff`
`fff`qqqqqqqqqqqqqqqqqq`fff`
``````qqqqqqqqqqqqqqqq``````'''
xpm_shell = '''16 16 32 1
o c None
` c #243e84
. c #d4deec
# c #3c62b4
a c #2c52a4
b c #5476bc
c c #2c4a94
d c #4c6ebc
e c #24468c
f c #f4f6fc
g c #3c5eb4
h c #446abc
i c #3456ac
j c #6482c4
k c #2c4e9c
l c #5472bc
m c #244284
n c #e4eaf4
p c #5c7ac4
q c #4466b4
r c #2c56b4
s c #4c72bc
t c #2c4a9c
u c #244694
v c #000000
w c #000000
x c #000000
y c #000000
z c #000000
A c #000000
B c #000000
C c #000000
oooooooooooooooo
ojbdqqq#qq#qgiao
jnrirrirrinrnrnk
jririrrirrrrrrrc
p.............nu
l.ffffffffffffnu
s.ffffffffffffne
l.ffffffffffffne
s.ffffffffffffne
l.ffffffffffffne
s.foffoffoffofne
d.ffffffffffffne
h.ffffffffffffnm
qnnnnnnnnnnnnnn`
ograkukukukukemo
oooooooooooooooo'''
xpm_main_icon = '''32 32 3 1
 	c None
;	c #00FF00
,	c #0000FF
   ,,,    ,,       ,     ,,,,   
  ,;;;,  ,;;,     ,;,   ,;;;;,  
 ,;;;;;, ,;;,     ,;,  ,;;;;;;, 
 ,;;;;;;, ,;,     ,;,  ,;;;;;;, 
,;;,,,;;, ,;,     ,;, ,;;,,,,;;,
,;;,  ,;, ,;,    ,;;, ,;;,  ,;;,
,;,   ,;;,,;,    ,;;,,;;,    ,;,
,;,   ,;;,,;;,   ,;, ,;;,    ,;,
,;,   ,;;,,;;,   ,;, ,;;,    ,;,
,;,    ,;,,;;,   ,;, ,;,     ,;,
,;,     ,  ,;,   ,;, ,;,      , 
,;;,       ,;,   ,;, ,;,        
,;;,,      ,;,  ,;;, ,;,        
,;;;;,     ,;,  ,;;, ,;,        
 ,;;;;,    ,;,  ,;,  ,;,        
 ,;;;;;,   ,;;, ,;, ,;;,   ,,,,,
  ,,;;;;,  ,;;, ,;, ,;;,  ,;;;;;
    ,;;;,   ,;, ,;,  ,;,  ,;;;;;
     ,;;;,  ,;, ,;,  ,;,  ,;;;;;
      ,;;,  ,;,,;;,  ,;,   ,,,;;
 ,     ,;,  ,;,,;,   ,;,     ,;;
,;,    ,;,  ,;,,;,   ,;,     ,;;
;;,    ,;,  ,;;,;,   ,;,     ,;;
;;,    ,;,  ,;;,;,   ,;;,    ,;;
,;,    ,;,   ,;,;,   ,;;,    ,;;
,;,    ,;,   ,;,;,   ,;;,    ,;;
,;;,  ,;;,   ,;;;,    ,;;,   ,;;
,;;,,,,;,    ,;;;,    ,;;,,,,;;,
,;;;;;;;,    ,;;;,     ,;;;;;;;,
 ,;;;;;;,     ,;,      ,;;;;;;, 
  ,;;;;,      ,;,       ,;;;;,  
   ,,,,        ,         ,,,,   '''

def print_error():
	exc, err, traceback = sys.exc_info()
	print exc, traceback.tb_frame.f_code.co_filename, 'ERROR ON LINE', traceback.tb_lineno, '\n', err
	del exc, err, traceback

def rescale_bmp(bmp, scale):
	img = bmp.ConvertToImage()
	img.Rescale(scale[0], scale[1])
	return img.ConvertToBitmap()

def open_settings(filename):
	conf = wx.FileConfig(localFilename = filename)
	def create_entry(entry_name, entry_value):
		if not conf.HasEntry(entry_name):
			if isinstance(entry_value, (str, unicode)):
				conf.Write(entry_name, entry_value)
			elif isinstance(entry_value, int):
				conf.WriteInt(entry_name, entry_value)
			elif isinstance(entry_value, bool):
				conf.WriteBool(entry_name, entry_value)
			else:
				conf.Write(entry_name, repr(entry_value))
			return True
		else:
			return False
	flag_flush = False
	if create_entry('Language/Catalog', getdefaultlocale()[0]):
		flag_flush = True
	if create_entry('GUI/load_default_perspective_on_start', True):
		flag_flush = True
	if create_entry('GUI/save_default_perspective_on_exit', True):
		flag_flush = True
	if create_entry('GUI/perspective', ''):
		flag_flush = True
	if create_entry('GUI/load_default_state_on_start', True):
		flag_flush = True
	if create_entry('GUI/save_default_state_on_exit', True):
		flag_flush = True
	if create_entry('GUI/fullscreen_style', default_fullscreen_style):
		flag_flush = True
	if create_entry('GUI/centre_on_screen', repr((False, wx.BOTH))):
		flag_flush = True
	if create_entry('GUI/default_open_path', '.'):
		flag_flush = True
	if flag_flush:
		conf.Flush()
	return conf

class log_ctrl(wx.TextCtrl):
	def __init__(self, *args, **kwargs):
		self.file_name = kwargs.pop('file_name', 'log.txt')
		self.main_frame = kwargs.pop('main_frame', None)
		self.add_to_file = kwargs.pop('add_to_file', False)
		if self.main_frame is None:
			self.main_frame = args[0]
		super(log_ctrl, self).__init__(*args, **kwargs)
	def __write__(self, content):
		self.WriteText(content)
	def show_control(self, ctrl_name = 'log_ctrl'):
		if self.main_frame is not None:
			if hasattr(self.main_frame,'aui_manager'):
				self.main_frame.show_aui_pane_info(ctrl_name)
		self.SetInsertionPointEnd()
		if self.add_to_file: self.flush()
	def write(self, content):
		self.show_control()
		self.__write__(content)
	def writelines(self, l):
		self.show_control()
		map(self.__write__, l)
	def flush(self):
		self.SaveFile(self.file_name)
	def print_error(self):
		exc, err, traceback = sys.exc_info()
		self.write(repr(exc) + ' ' + traceback.tb_frame.f_code.co_filename + ' ERROR ON LINE ' + str(traceback.tb_lineno) + '\n' + repr(err) + '\n')
		del exc, err, traceback

class shell_control(shell.Shell):
	HELP_TEXT = shell.HELP_TEXT
	def __init__(self, parent = None, ID = wx.ID_ANY):
		self.mf = parent
		str1 = _('Console')
		self.intro_text = '%s Python - %s (wxPython - %s)' % (str1, version.VERSION, wx.VERSION_STRING)
		shell.Shell.__init__(self, parent, ID, style = wx.CLIP_CHILDREN, introText = self.intro_text, locals = locals())
		self.redirectStdin()
		#~ self.redirectStdout()
		#~ self.redirectStderr()

	def __del__(self):
		self.redirectStdin(False)
		self.redirectStdout(False)
		self.redirectStderr(False)
		self.mf.shell = None

	def prn(self, value):
		print value
		self.prompt()

	def clear_text(self):
		self.clear()
		self.showIntro(self.intro_text)
		self.prompt()

	def help(self):
		self.prn(self.HELP_TEXT)

class svg_panel(ScrolledPanel):
	def __init__(self, *args, **kwargs):
		self.main_frame = kwargs.pop('main_frame', None)
		if self.main_frame is None:
			self.main_frame = args[0]
		super(svg_panel, self).__init__(*args, **kwargs)
		sizer = wx.GridSizer(1, 1)
		self.svg_canvas = svg_canvas(self, use_cairo = False, file_name = self.main_frame.open_file_name)
		sizer.Add(self.svg_canvas, 0, wx.EXPAND | wx.ALL)
		self.SetSizer(sizer)
		self.SetAutoLayout(1)
		self.SetupScrolling()

class main_frame(wx.Frame):
	def __init__(self, *args, **kwargs):
		self.app = kwargs.pop('app', None)
		self.open_file_name = kwargs.pop('open_file_name', '')
		wx.Frame.__init__(self, *args, **kwargs)
		self.default_title = self.GetTitle()
		#~ self.SetIcon(wx.IconFromBitmap(wx.BitmapFromXPMData(xpm_main_icon.split('\n'))))
		self.SetIcon(wx.IconFromBitmap(svg_to_bitmap(logo, (32, 32), use_cairo = False)))

		#Logging Text Control
		self.log_ctrl = log_ctrl(self, style = wx.TE_MULTILINE)
		sys.stdout = self.log_ctrl
		sys.stderr = self.log_ctrl
		self.log = wx.LogTextCtrl(self.log_ctrl)
		self.log.SetLogLevel(wx.LOG_Error)
		wx.Log_SetActiveTarget(self.log)

		self.print_data = wx.PrintData()
		self.page_setup_dialog_data = wx.PageSetupDialogData()

		id_about = wx.ID_ABOUT
		id_exit = wx.ID_EXIT
		id_help = wx.ID_HELP
		id_clear_shell = wx.NewId()
		id_show_toolbar = wx.NewId()
		id_show_shell = wx.NewId()
		id_show_log_ctrl = wx.NewId()
		id_show_full_screen = wx.NewId()
		id_save_default_perspective = wx.NewId()
		id_convert_to_raster_and_save = wx.NewId()

		img_size = (16, 16)
		bmp_open = wx.ArtProvider_GetBitmap(wx.ART_FILE_OPEN, wx.ART_OTHER, img_size)
		bmp_saveas = wx.ArtProvider_GetBitmap(wx.ART_FILE_SAVE_AS, wx.ART_OTHER, img_size)
		bmp_print = wx.ArtProvider_GetBitmap(wx.ART_PRINT, wx.ART_OTHER, img_size)
		bmp_preview = wx.ArtProvider_GetBitmap(wx.ART_NORMAL_FILE, wx.ART_OTHER, img_size)
		bmp_page_setup = wx.ArtProvider_GetBitmap(wx.ART_HELP_PAGE, wx.ART_OTHER, img_size)
		bmp_quit = wx.ArtProvider_GetBitmap(wx.ART_QUIT, wx.ART_OTHER, img_size)
		bmp_about = wx.ArtProvider_GetBitmap(wx.ART_HELP_SETTINGS, wx.ART_OTHER, img_size)
		bmp_help = wx.ArtProvider_GetBitmap(wx.ART_HELP_BOOK, wx.ART_OTHER, img_size)
		bmp_zoom_100 = wx.ArtProvider_GetBitmap(wx.ART_INFORMATION, wx.ART_OTHER, img_size)
		bmp_clear_shell = wx.BitmapFromXPMData(xpm_clear.split('\n'))
		bmp_show_log_ctrl = wx.BitmapFromXPMData(log_xpm.split('\n'))
		bmp_show_toolbar = wx.ArtProvider_GetBitmap(wx.ART_ADD_BOOKMARK, wx.ART_OTHER, img_size)
		bmp_show_shell = wx.BitmapFromXPMData(xpm_shell.split('\n'))
		bmp_save_default_perspective = wx.ArtProvider_GetBitmap(wx.ART_HELP_SIDE_PANEL, wx.ART_OTHER, img_size)
		bmp_show_full_screen = rescale_bmp(wx.BitmapFromXPMData(xpm_fullscreen.split('\n')), img_size)
		bmp_convert_to_raster_and_save = wx.ArtProvider_GetBitmap(wx.ART_NEW_DIR, wx.ART_OTHER, img_size)

		self.menubar = wx.MenuBar()
		self.SetMenuBar(self.menubar)

		tmp_menu = wx.Menu()
		menu_item = wx.MenuItem(tmp_menu, wx.ID_OPEN, _('Open'), _('Open'), wx.ITEM_NORMAL)
		menu_item.SetBitmap(bmp_open)
		tmp_menu.AppendItem(menu_item)
		menu_item = wx.MenuItem(tmp_menu, wx.ID_SAVEAS, _('Save As...'), _('Save As...'), wx.ITEM_NORMAL)
		menu_item.SetBitmap(bmp_saveas)
		tmp_menu.AppendItem(menu_item)
		menu_item = wx.MenuItem(tmp_menu, id_convert_to_raster_and_save, _('Save bitmap'), _('Save to file as raster graphics.'), wx.ITEM_NORMAL)
		menu_item.SetBitmap(bmp_convert_to_raster_and_save)
		tmp_menu.AppendItem(menu_item)
		menu_item = wx.MenuItem(tmp_menu, wx.ID_PRINT, _('Print'), _('Print'), wx.ITEM_NORMAL)
		menu_item.SetBitmap(bmp_print)
		tmp_menu.AppendItem(menu_item)
		menu_item = wx.MenuItem(tmp_menu, wx.ID_PREVIEW, _('Preview'), _('Preview'), wx.ITEM_NORMAL)
		menu_item.SetBitmap(bmp_preview)
		tmp_menu.AppendItem(menu_item)
		menu_item = wx.MenuItem(tmp_menu, wx.ID_PAGE_SETUP, _('Page Setup'), _('Page Setup'), wx.ITEM_NORMAL)
		menu_item.SetBitmap(bmp_page_setup)
		tmp_menu.AppendItem(menu_item)
		menu_item = wx.MenuItem(tmp_menu, id_clear_shell, _('&clear'), _('clear shell'), wx.ITEM_NORMAL)
		menu_item.SetBitmap(bmp_clear_shell)
		tmp_menu.AppendItem(menu_item)
		menu_item = wx.MenuItem(tmp_menu, id_exit, _('&Quit'), _('Exit from this application'), wx.ITEM_NORMAL)
		menu_item.SetBitmap(bmp_quit)
		tmp_menu.AppendItem(menu_item)
		self.menubar.Append(tmp_menu, _('File'))

		tmp_menu = wx.Menu()
		menu_item = wx.MenuItem(tmp_menu, wx.ID_ZOOM_100, _('Zoom 100'), _('Zoom to original size'), wx.ITEM_NORMAL)
		menu_item.SetBitmap(bmp_zoom_100)
		tmp_menu.AppendItem(menu_item)
		self.menubar.Append(tmp_menu, _('Zoom'))

		tmp_menu = wx.Menu()
		menu_item = wx.MenuItem(tmp_menu, id_show_toolbar, _('Show &toolbar'), _('Show main toolbar'), wx.ITEM_NORMAL)
		menu_item.SetBitmap(bmp_show_toolbar)
		tmp_menu.AppendItem(menu_item)
		menu_item = wx.MenuItem(tmp_menu, id_show_shell, _('Show &shell'), _('Show shell'), wx.ITEM_NORMAL)
		menu_item.SetBitmap(bmp_show_shell)
		tmp_menu.AppendItem(menu_item)
		menu_item = wx.MenuItem(tmp_menu, id_show_log_ctrl, _('Show &log'), _('Show log'), wx.ITEM_NORMAL)
		menu_item.SetBitmap(bmp_show_log_ctrl)
		tmp_menu.AppendItem(menu_item)
		menu_item = wx.MenuItem(tmp_menu, id_show_full_screen, _('Show full screen'), _('Show frame into full screen mode'), wx.ITEM_NORMAL)
		menu_item.SetBitmap(bmp_show_full_screen)
		tmp_menu.AppendItem(menu_item)
		menu_item = wx.MenuItem(tmp_menu, id_save_default_perspective, _('Save default perspective'), _('Save default perspective'), wx.ITEM_NORMAL)
		menu_item.SetBitmap(bmp_save_default_perspective)
		tmp_menu.AppendItem(menu_item)
		self.menubar.Append(tmp_menu, _('Show'))

		tmp_menu = wx.Menu()
		menu_item = wx.MenuItem(tmp_menu, id_about, _('&About'), _('About authors'), wx.ITEM_NORMAL)
		menu_item.SetBitmap(bmp_about)
		tmp_menu.AppendItem(menu_item)
		menu_item = wx.MenuItem(tmp_menu, id_help, _('&Help'), _('Help for this application'), wx.ITEM_NORMAL)
		menu_item.SetBitmap(bmp_help)
		tmp_menu.AppendItem(menu_item)
		self.menubar.Append(tmp_menu, _('Help'))

		self.main_toolbar = AuiToolBar(self, style = AUI_TB_DEFAULT_STYLE|AUI_TB_VERTICAL|AUI_TB_OVERFLOW)
		self.main_toolbar.AddTool(wx.ID_OPEN, _('Open'), bmp_open, wx.NullBitmap, wx.ITEM_NORMAL, _('Open'), _('Open'), None)
		self.main_toolbar.AddTool(wx.ID_SAVEAS, _('Save As...'), bmp_saveas, wx.NullBitmap, wx.ITEM_NORMAL, _('Save As...'), _('Save As...'), None)
		self.main_toolbar.AddTool(id_convert_to_raster_and_save, _('Save bitmap'), bmp_convert_to_raster_and_save, wx.NullBitmap, wx.ITEM_NORMAL, _('Save bitmap'), _('Save to file as raster graphics.'), None)
		self.main_toolbar.AddTool(wx.ID_PRINT, _('Print'), bmp_print, wx.NullBitmap, wx.ITEM_NORMAL, _('Print'), _('Print'), None)
		self.main_toolbar.AddTool(wx.ID_PREVIEW, _('Preview'), bmp_preview, wx.NullBitmap, wx.ITEM_NORMAL, _('Preview'), _('Preview'), None)
		self.main_toolbar.AddTool(wx.ID_PAGE_SETUP, _('Page Setup'), bmp_page_setup, wx.NullBitmap, wx.ITEM_NORMAL, _('Page Setup'), _('Page Setup'), None)
		self.main_toolbar.AddTool(wx.ID_ZOOM_100, _('Zoom 100'), bmp_zoom_100, wx.NullBitmap, wx.ITEM_NORMAL, _('Zoom 100 percents'), _('Zoom to original size'), None)
		self.main_toolbar.AddTool(id_show_full_screen, _('Show full screen'), bmp_show_full_screen, wx.NullBitmap, wx.ITEM_NORMAL, _('Show full screen'), _('Show frame into full screen mode'), None)
		self.main_toolbar.AddTool(id_about, _('Authors'), bmp_about, wx.NullBitmap, wx.ITEM_NORMAL, _('Version application, author'), _('Version application, author'), None)
		self.main_toolbar.AddTool(id_exit, _('Exit'), bmp_quit, wx.NullBitmap, wx.ITEM_NORMAL, _('Exit from application'), _('Exit from application'), None)
		self.main_toolbar.Realize()

		self.shell = shell_control(self)
		self.svg_panel = svg_panel(self)

		self.pane_captions = {
							'main_toolbar':('main_toolbar', _('main toolbar')),
							'svg_panel':('svg_panel', _('svg panel')),
							'log_ctrl':('log', _('log')),
							'shell':('shell', _('shell'))
							}

		self.aui_manager = AuiManager()
		self.aui_manager.SetManagedWindow(self)

		self.aui_manager.AddPane(self.svg_panel, AuiPaneInfo().Name('svg_panel').CenterPane().BestSize((100, 100)))
		self.aui_manager.AddPane(self.main_toolbar, AuiPaneInfo().ToolbarPane().Name('main_toolbar').Left())
		self.aui_manager.AddPane(self.log_ctrl, AuiPaneInfo().Name('log_ctrl').Bottom().Layer(0).BestSize((100, 100)).Hide())
		self.aui_manager.AddPane(self.shell, AuiPaneInfo().Name('shell').Bottom().Layer(1).MaximizeButton(True).Hide())

		if self.app.settings.ReadBool('GUI/load_default_perspective_on_start', True):
			self.aui_manager.LoadPerspective(self.app.settings.Read('GUI/perspective', ''))
		if self.log_ctrl.GetValue() != '':
			self.aui_manager.GetPane('log_ctrl').Show()
		self.aui_manager.Update()

		self.method_set_translation_pane_captions()

		self.sb = self.CreateStatusBar(2)

		wx.EVT_CLOSE(self, self.event_close)

		wx.EVT_MENU(self, id_exit, self.event_exit)
		wx.EVT_MENU(self, id_about, self.event_about)
		wx.EVT_MENU(self, id_help, self.event_help)

		wx.EVT_MENU(self, wx.ID_ZOOM_100, self.event_zoom_100)
		wx.EVT_MENU(self, wx.ID_OPEN, self.event_open)
		wx.EVT_MENU(self, wx.ID_SAVEAS, self.event_saveas)
		wx.EVT_MENU(self, wx.ID_PRINT, self.event_print)
		wx.EVT_MENU(self, wx.ID_PREVIEW, self.event_preview)
		wx.EVT_MENU(self, wx.ID_PAGE_SETUP, self.event_page_setup)
		wx.EVT_MENU(self, id_clear_shell, self.event_clear_shell)
		wx.EVT_MENU(self, id_convert_to_raster_and_save, self.event_convert_to_raster_and_save)

		wx.EVT_MENU(self, id_show_toolbar, self.event_show_toolbar)
		wx.EVT_MENU(self, id_show_shell, self.event_show_shell)
		wx.EVT_MENU(self, id_show_log_ctrl, self.event_show_log_ctrl)
		wx.EVT_MENU(self, id_show_full_screen, self.event_show_full_screen)
		wx.EVT_MENU(self, id_save_default_perspective, self.event_save_default_perspective)

		if self.app.settings.ReadBool('GUI/load_default_state_on_start', True):
			self.method_load_default_state()

		self.default_open_path = self.app.settings.Read('GUI/default_open_path', os.getcwd())
		if os.path.isfile(self.open_file_name):
			self.SetStatusText(self.open_file_name, 1)
			self.default_open_path = os.path.dirname(self.open_file_name)

	def event_zoom_100(self, event):
		self.svg_panel.svg_canvas.zoom_to_original_size()

	def event_open(self, event):
		wildcard = 'SVG files (*.svg)|*.svg|'\
					'SVGZ files (*.svgz)|*.svgz|'\
					'All files (*.*)|*.*'
		dlg = wx.FileDialog(self, message = _('Choose a file'),
			defaultDir = self.default_open_path,  defaultFile = '',
			wildcard = wildcard, style = wx.OPEN|wx.CHANGE_DIR)
		if dlg.ShowModal() == wx.ID_OK:
			self.svg_panel.svg_canvas.draw_file(dlg.GetPath())
			self.SetStatusText(dlg.GetPath(), 1)
			title = self.svg_panel.svg_canvas.svg_data.get('title', None)
			if title:
				self.SetTitle(self.default_title + ' (' + title + ')')
			else:
				if self.GetTitle() is not self.default_title:
					self.SetTitle(self.default_title)
			desc = self.svg_panel.svg_canvas.svg_data.get('desc', None)
			if desc:
				print desc
		dlg.Destroy()
		self.svg_panel.SetFocus()

	def event_saveas(self, event):
		wildcard = 'PYSVG files (*.pysvg)|*.pysvg|'\
					'All files (*.*)|*.*'
		new_name = self.svg_panel.svg_canvas.file_name.replace('.svg', '')
		dlg = wx.FileDialog(self, _('Save a file'), self.default_open_path,  new_name, wildcard, wx.SAVE|wx.CHANGE_DIR)
		if dlg.ShowModal() == wx.ID_OK:
			f = open(dlg.GetPath(), 'w')
			f.write(repr(self.svg_panel.svg_canvas.svg_data))
			f.close()
		dlg.Destroy()

	def event_convert_to_raster_and_save(self, event):
		self.svg_panel.svg_canvas.save_raster_graphics_to_file()

	def event_print(self, event):
		print_dialog_data = wx.PrintDialogData(self.print_data)
		print_dialog_data.SetToPage(2)
		printer = wx.Printer(print_dialog_data)
		printout = svg_printout(canvas = self.svg_panel.svg_canvas)
		if not printer.Print(self, printout, True):
			wx.MessageBox(_('There was a problem printing.\nPerhaps your current printer is not set correctly?'), _('Warning'))
		else:
			self.print_data = wx.PrintData(printer.GetPrintDialogData().GetPrintData())
		printout.Destroy()

	def event_preview(self, event):
		print_dialog_data = wx.PrintDialogData(self.print_data)
		printout = svg_printout(canvas = self.svg_panel.svg_canvas)
		printout2 = svg_printout(canvas = self.svg_panel.svg_canvas)
		print_preview = wx.PrintPreview(printout, printout2, print_dialog_data)
		if not print_preview.Ok():
			wx.MessageBox(_('There was a problem print preview.\nPerhaps your current printer is not set correctly?'), _('Warning'))
			return
		preview_frame = wx.PreviewFrame(print_preview, self, self.svg_panel.svg_canvas.file_name)
		preview_frame.Initialize()
		preview_frame.SetPosition(self.GetPosition())
		preview_frame.SetSize(self.GetSize())
		preview_frame.Show(True)

	def event_page_setup(self, event):
		self.page_setup_dialog_data.EnableHelp(True)
		self.print_data = wx.PrintData(self.print_data)
		self.page_setup_dialog_data = wx.PageSetupDialogData(self.page_setup_dialog_data)
		if not self.print_data.IsOk():
			wx.MessageBox(_('There was a problem during page setup: you may need to set a default printer.'), _('Warning'))
			return
		self.page_setup_dialog_data.SetPrintData(self.print_data)
		if not self.page_setup_dialog_data.IsOk():
			wx.MessageBox(_('There was a problem during page setup: you may need to set a default printer.'), _('Warning'))
			return
		dlg = wx.PageSetupDialog(self, self.page_setup_dialog_data)
		if dlg.ShowModal() == wx.ID_OK:
			self.page_setup_dialog_data = dlg.GetPageSetupData()
			self.print_data = wx.PrintData(self.page_setup_dialog_data.GetPrintData())
		dlg.Destroy()

	def method_set_default_pane_captions(self):
		for name, caption in self.pane_captions.iteritems():
			self.aui_manager.GetPane(name).Caption(caption[0])

	def method_set_translation_pane_captions(self):
		for name, caption in self.pane_captions.iteritems():
			self.aui_manager.GetPane(name).Caption(caption[1])

	def method_load_default_state(self):
		frame_font = wx.SystemSettings_GetFont(wx.SYS_DEFAULT_GUI_FONT)
		frame_font.SetNativeFontInfoFromString(self.app.settings.Read('GUI/font', ''))
		self.SetFont(frame_font)
		self.SetSize(eval(self.app.settings.Read('GUI/size', '(100,100)')))
		self.SetPosition(eval(self.app.settings.Read('GUI/position', '(100,100)')))
		centre_on_screen = eval(self.app.settings.Read('GUI/centre_on_screen', repr((False, wx.BOTH))))
		if centre_on_screen[0]:
			self.CentreOnScreen(centre_on_screen[1])
		self.Maximize(self.app.settings.ReadBool('GUI/maximized', False))
		self.Iconize(self.app.settings.ReadBool('GUI/iconized', False))
		self.ShowFullScreen(self.app.settings.ReadBool('GUI/fullscreen', False), self.app.settings.ReadInt('GUI/fullscreen_style', default_fullscreen_style))

	def method_save_default_state(self):
		flag_flush = False
		position = self.GetPositionTuple()
		if position != eval(self.app.settings.Read('GUI/position', '()')):
			self.app.settings.Write('GUI/position', repr(position))
			flag_flush = True
		size = self.GetSizeTuple()
		if size != eval(self.app.settings.Read('GUI/size', '()')):
			self.app.settings.Write('GUI/size', repr(size))
			flag_flush = True
		font = self.GetFont().GetNativeFontInfo().ToString()
		if font != self.app.settings.Read('GUI/font', ''):
			self.app.settings.Write('GUI/font', font)
			flag_flush = True
		is_maximized = self.IsMaximized()
		if is_maximized != self.app.settings.ReadBool('GUI/maximized', False):
			self.app.settings.WriteBool('GUI/maximized', is_maximized)
			flag_flush = True
		is_iconized = self.IsIconized()
		if is_iconized != self.app.settings.ReadBool('GUI/iconized', False):
			self.app.settings.WriteBool('GUI/iconized', is_iconized)
			flag_flush = True
		is_fullscreen = self.IsFullScreen()
		if is_fullscreen != self.app.settings.ReadBool('GUI/fullscreen', False):
			self.app.settings.WriteBool('GUI/fullscreen', is_fullscreen)
			flag_flush = True
		if flag_flush:
			self.app.settings.Flush()

	def method_save_default_perspective(self):
		self.method_set_default_pane_captions()
		current_perspective = self.aui_manager.SavePerspective()
		self.method_set_translation_pane_captions()
		if self.app.settings.Read('GUI/perspective', '') != current_perspective:
			self.app.settings.Write('GUI/perspective', current_perspective)
			self.app.settings.Flush()

	def event_save_default_perspective(self, event):
		self.method_save_default_perspective()
		wx.MessageBox(_('Reload application for view new settings!'), _('WARNING'), wx.ICON_INFORMATION)

	def show_aui_pane_info(self, name):
		if not self.aui_manager.GetPane(name).IsShown():
			self.aui_manager.GetPane(name).Show()
			self.aui_manager.Update()

	def show_hide_aui_pane_info(self, name):
		if self.aui_manager.GetPane(name).IsShown():
			self.aui_manager.GetPane(name).Hide()
		else:
			self.aui_manager.GetPane(name).Show()
		self.aui_manager.Update()

	def event_show_toolbar(self, event):
		self.show_hide_aui_pane_info('main_toolbar')

	def event_show_shell(self, event):
		self.show_hide_aui_pane_info('shell')

	def event_show_log_ctrl(self, event):
		self.show_hide_aui_pane_info('log_ctrl')

	def event_show_full_screen(self, event):
		self.ShowFullScreen(not self.IsFullScreen(), self.app.settings.ReadInt('GUI/fullscreen_style', default_fullscreen_style))

	def DoUpdate(self):
		self.aui_manager.Update()

	def event_exit(self, event):
		self.Close()

	def event_close(self, event):
		if self.app.settings.ReadBool('GUI/save_default_state_on_exit', True):
			self.method_save_default_state()
		if self.app.settings.ReadBool('GUI/save_default_perspective_on_exit', True):
			self.method_save_default_perspective()
		self.main_toolbar.Destroy()
		self.aui_manager.UnInit()
		self.Destroy()

	def event_about(self, event):
		info = wx.AboutDialogInfo()
		info.Name = _(self.app.app_name)
		info.Version = self.app.app_version
		info.Copyright = _('(C) 2009 Max Kolosov')
		info.Description = self.app.app_name + _(' - svg viewer/converter.')
		info.WebSite = ('http://saxi.nm.ru', _('home page'))
		info.Developers = [_('Max Kolosov')]
		info.License = _('BSD license')
		wx.AboutBox(info)

	def event_help(self, event):
		self.app.help_controller.Display('default.html')
		self.app.activate_frame(self.app.help_controller.GetFrame())

	def event_clear_shell(self, event):
		self.shell.clear_text()

class app(wx.PySimpleApp):

	app_version = _version
	app_path = os.getcwd()
	app_name = os.path.basename(sys.argv[0].split('.')[0])
	help_file = app_name + '.htb'
	settings_name = app_path + '/' + app_name + '.cfg'
	settings = open_settings(settings_name)
	wx_coding = 'ansi'

	def on_init(self, file_name = ''):
		global _
		name_user = wx.GetUserId()
		name_instance = self.app_name + '::'
		self.instance_checker = wx.SingleInstanceChecker(name_instance + name_user)
		if self.instance_checker.IsAnotherRunning():
			wx.MessageBox(_('Software is already running.'), _('Warning'))
			return False
		#~ wx.InitAllImageHandlers()
		# SETUP TRANSLATIONS
		lang_catalog = self.settings.Read('Language/Catalog', getdefaultlocale()[0])
		list_trans = []
		current_trans = -1
		i = 0
		if wx.USE_UNICODE:
			self.wx_coding = 'unicode'
		root_lang = self.app_path + '/lang'
		if os.path.exists(root_lang):
			lang_path = '%s/%s' % (root_lang, lang_catalog)
			if not os.path.isdir(lang_path): os.mkdir(lang_path)
			for dir_name in os.listdir(root_lang):
				translate_file = '%s/%s/%s_%s.mo'%(root_lang, dir_name, self.app_name, self.wx_coding)
				if os.path.isfile(translate_file):
					if dir_name == lang_catalog:
						current_trans = i
						self.help_file = root_lang + '/' + dir_name + '/' + self.help_file
					list_trans.append(gettext.GNUTranslations(open(translate_file, 'rb')))
					i += 1
			if len(list_trans) > 0:
				try:
					list_trans[current_trans].install(unicode = wx.USE_UNICODE)
				except:
					print_error()
				else:
					_ = list_trans[current_trans].gettext
		if current_trans == -1:
			trans = gettext.NullTranslations()
			trans.install(unicode = wx.USE_UNICODE)
		# SETUP WX LANGUAGE TRANSLATION TO OS DEFAULT LANGUAGE
		# WX DIRECTORY MUST BE CONTAIN LANG DIRECTORY
		self.locale = wx.Locale(wx.LANGUAGE_DEFAULT)
		# CREATE HTML HELP CONTROLLER
		wx.FileSystem.AddHandler(wx.ZipFSHandler())
		self.help_controller = HtmlHelpController()
		if os.path.exists(self.help_file):
			self.help_controller.AddBook(self.help_file)
		# CREATE MAIN FRAME
		self.mf = main_frame(None, app = self, open_file_name = file_name, title = _(self.app_name) + ' ' + self.app_version)
		self.SetTopWindow(self.mf)
		self.mf.Show()
		return True

	def OnExit(self):
		try:
			del self.instance_checker
		except:
			print_error()

	def activate_frame(self, frame):
		if frame is not None or not isinstance(frame, wx._core._wxPyDeadObject):
			if frame.IsIconized():
				frame.Restore()
			else:
				from platform import system
				if system().lower() == 'linux':
					frame.Iconize(False)
				frame.SetFocus()

def main(file_name = ''):
	gui_app = app(0)
	if gui_app.on_init(file_name):
		gui_app.MainLoop()
	else:
		gui_app.OnExit()

if __name__=='__main__':
	from optparse import OptionParser
	parser = OptionParser(version='%prog ' + _version + '\nrun into python: ' + sys.version, description = '"version %s - %s"' % (__file__, _version))
	parser.add_option('-f', '--file_name', dest='file_name', default='', help='open file file_name', metavar='FILE')
	(options, args) = parser.parse_args()
	if len(args) > 0 and options.file_name == '':
		options.file_name = args[0]
	main(options.file_name)
