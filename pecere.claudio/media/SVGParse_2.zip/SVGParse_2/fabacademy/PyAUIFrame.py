# -*- coding: utf-8 -*- 

import wx
import wx.grid
import wx.html
import wx.aui

import xml.dom.minidom
import parse_path

import datetime

#Various functions

#Module for log
import sys
import  os

import cStringIO


ID_About = wx.NewId()

#----------------------------------------------------------------------
class RedirectText(object):
    # Redirect the print message to the Status log area
    def __init__(self,wxLog):
        self.out=wxLog

    def write(self,string):
        self.out.WriteText(string)




class PyAUIFrame(wx.Frame):
    
    def __init__(self, parent, id=-1, title="wxGestalt", pos=wx.DefaultPosition,
                 size = wx.Size( 900,700 ), style=wx.DEFAULT_FRAME_STYLE |
                                            wx.SUNKEN_BORDER |
                                            wx.CLIP_CHILDREN):

        wx.Frame.__init__(self, parent, id, title, pos, size, style)
        
        # tell FrameManager to manage this frame        
        self._mgr = wx.aui.AuiManager()
        self._mgr.SetManagedWindow(self)
        
        
        self.n = 0
        self.x = 0
        self.xl = 400
        self.yl = 400
        
        

        # create menu
        
        
        self.m_menubar1 = wx.MenuBar( 0 )
        self.m_menu1 = wx.Menu()
        self.m_menuItem1 = wx.MenuItem( self.m_menu1, wx.ID_ANY, u"New Machine", wx.EmptyString, wx.ITEM_NORMAL )
        self.m_menu1.AppendItem( self.m_menuItem1 )
        
        self.m_menuItem2 = wx.MenuItem( self.m_menu1, wx.ID_ANY, u"Open a Machine", wx.EmptyString, wx.ITEM_NORMAL )
        self.m_menu1.AppendItem( self.m_menuItem2 )
        
        self.m_menuItem7 = wx.MenuItem( self.m_menu1, wx.ID_ANY, u"Save a Machine", wx.EmptyString, wx.ITEM_NORMAL )
        self.m_menu1.AppendItem( self.m_menuItem7 )
        
        self.m_menuItem3 = wx.MenuItem( self.m_menu1, wx.ID_ANY, u"Quit", wx.EmptyString, wx.ITEM_NORMAL )
        self.m_menu1.AppendItem( self.m_menuItem3 )
        
        self.m_menubar1.Append( self.m_menu1, u"Machine" ) 
        
        self.m_menu4 = wx.Menu()
        self.m_menuItem5 = wx.MenuItem( self.m_menu4, wx.ID_ANY, u"Load SVG", wx.EmptyString, wx.ITEM_NORMAL )
        self.m_menu4.AppendItem( self.m_menuItem5 )
        
        self.m_menuItem6 = wx.MenuItem( self.m_menu4, wx.ID_ANY, u"Launch Job", wx.EmptyString, wx.ITEM_NORMAL )
        self.m_menu4.AppendItem( self.m_menuItem6 )
        
        self.m_menubar1.Append( self.m_menu4, u"CAM Job" ) 
        
        self.m_menu2 = wx.Menu()
        self.m_menuItem4 = wx.MenuItem( self.m_menu2, wx.ID_ANY, u"Serial Port", wx.EmptyString, wx.ITEM_NORMAL )
        self.m_menu2.AppendItem( self.m_menuItem4 )
        
        self.m_menubar1.Append( self.m_menu2, u"Settings" ) 
        
        help_menu = wx.Menu()
        help_menu.Append(ID_About, "About...")
        
        self.m_menubar1.Append( help_menu, u"Help" )
        
        self.SetMenuBar( self.m_menubar1 )

        self.statusbar = self.CreateStatusBar(2, wx.ST_SIZEGRIP)
        self.statusbar.SetStatusWidths([-2, -3])
        self.statusbar.SetStatusText("Ready", 0)
        self.statusbar.SetStatusText("Welcome To wxGestalt!", 1)

        # min size for the frame itself isn't completely done.
        # see the end up FrameManager::Update() for the test
        # code. For now, just hard code a frame minimum size
        self.SetMinSize(wx.Size(400, 300))

        # create some toolbars. Insert in this section
        #
        
        #tb1 = wx.ToolBar(self, -1, wx.DefaultPosition, wx.DefaultSize,
        #                 wx.TB_FLAT | wx.TB_NODIVIDER)
        #tb1.SetToolBitmapSize(wx.Size(48,48))
        #tb1.AddLabelTool(101, "Test", wx.ArtProvider_GetBitmap(wx.ART_ERROR))
        #tb1.AddSeparator()
        #tb1.AddLabelTool(102, "Test", wx.ArtProvider_GetBitmap(wx.ART_QUESTION))
        #tb1.AddLabelTool(103, "Test", wx.ArtProvider_GetBitmap(wx.ART_INFORMATION))
        #tb1.AddLabelTool(103, "Test", wx.ArtProvider_GetBitmap(wx.ART_WARNING))
        #tb1.AddLabelTool(103, "Test", wx.ArtProvider_GetBitmap(wx.ART_MISSING_IMAGE))
        #tb1.Realize()
        

        # add panes
        
                      
        self.wxLog=wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 880,100 ), wx.TE_MULTILINE|wx.TE_READONLY|wx.TE_WORDWRAP|wx.FULL_REPAINT_ON_RESIZE|wx.VSCROLL )          
        
        
        
        self._mgr.AddPane(self.wxLog, wx.aui.AuiPaneInfo().
                          Name("consoleLog").Caption("Console Log").
                          Bottom().Layer(1).Position(1).CloseButton(False).MaximizeButton(True))
                                      
                
        self.m_notebook1 =self.CreateNotebook()
        
        self._mgr.AddPane(self.m_notebook1,wx.aui.AuiPaneInfo().
                          CenterPane())
        
        self.treeNodes=self.CreateTreeCtrl()
        
        self._mgr.AddPane(self.treeNodes, wx.aui.AuiPaneInfo().
                          Name("treeFolder").Caption(" Gestalt Nodes").Left().CloseButton(False).MaximizeButton(False).PaneBorder(False))
                      
        
        
        
        
        tabPanel= wx.Panel(self.m_notebook1,-1,wx.DefaultPosition,wx.Size( 500,300 ),wx.TAB_TRAVERSAL)
        
        page=self.CreateHTMLCtrl(tabPanel)
        
        self.m_notebook1.AddPage(tabPanel,"Welcome", False,0)
        
        redir=RedirectText(self.wxLog)
        
        sys.stdout=redir
        self.Show()
        print "Welcome"+'\n'     
        
                                
        # add the toolbars to the manager. Insert here this section
                        
        #self._mgr.AddPane(tb1, wx.aui.AuiPaneInfo().
        #                  Name("tb1").Caption("Big Toolbar").
        #                  ToolbarPane().Top().
        #                 LeftDockable(False).RightDockable(False))

                          
       

     
        

       
        # "commit" all changes made to FrameManager   
        self._mgr.Update()
        self.Bind(wx.EVT_MENU, self.OnAbout, id=ID_About)
        self.Bind( wx.EVT_MENU, self.On_Quit, id = self.m_menuItem3.GetId() )
        self.Bind( wx.EVT_MENU, self.On_ScanSerialPort, id = self.m_menuItem4.GetId() )
        self.Bind( wx.EVT_MENU, self.On_OpenSVG, id = self.m_menuItem5.GetId() )
        self.Bind( wx.EVT_MENU, self.On_OpenJob, id = self.m_menuItem6.GetId() )
        
        self.filepths= None
        
       

    
    def __del__( self ):
        pass
    
    
    # Virtual event handlers, overide them in your derived class
    def On_Quit( self, event ):
        event.Skip()
    
    def On_ScanSerialPort( self, event ):
        event.Skip()

    
    def OnAbout(self, event):

        msg = "wxGestalt \n" + \
              "A wxPython interface to the Gestalt system\n" + \
              "(http://mtm.cba.mit.edu/machines/science/ + https://github.com/imoyer/gestalt)"+\
              "Source code on https://github.com/openp2pdesign/wxGestalt"
        
        
        dlg = wx.MessageDialog(self, msg, "About wx.aui Demo",
                               wx.OK | wx.ICON_INFORMATION)
        dlg.ShowModal()
        dlg.Destroy()        


    def GetDockArt(self):

        return self._mgr.GetArtProvider()


    def DoUpdate(self):

        self._mgr.Update()



    def OnSize(self, event):

        event.Skip()

      

    def GetStartPosition(self):

        self.x = self.x + 20
        x = self.x
        pt = self.ClientToScreen(wx.Point(0, 0))
        
        return wx.Point(pt.x + x, pt.y + x)


      


    def CreateTextCtrl(self):

        text = (datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")+" Console started %d")%(self.n + 1)

        return wx.TextCtrl(self,-1, text, wx.Point(0, 0), wx.Size(150, 90),
                           wx.NO_BORDER | wx.TE_MULTILINE)


    def CreateNotebook(self):
            
        return wx.Notebook(self, -1, wx.Point(0, 0), wx.Size( 900,540 ), 0 )    
    


    def CreateTreeCtrl(self):

        tree = wx.TreeCtrl(self, -1, wx.Point(0, 0), wx.Size(160, 250),
                           wx.TR_DEFAULT_STYLE | wx.NO_BORDER)
        
        root = tree.AddRoot("Nodes")
        items = []

        imglist = wx.ImageList(16, 16, True, 2)
        imglist.Add(wx.ArtProvider_GetBitmap(wx.ART_FOLDER, wx.ART_OTHER, wx.Size(16,16)))
        imglist.Add(wx.ArtProvider_GetBitmap(wx.ART_NORMAL_FILE, wx.ART_OTHER, wx.Size(16,16)))
        tree.AssignImageList(imglist)

        items.append(tree.AppendItem(root, "Node1", 0))
        items.append(tree.AppendItem(root, "Node2", 0))
        items.append(tree.AppendItem(root, "Node3", 0))
        

        for ii in xrange(len(items)):
        
            id = items[ii]
            tree.AppendItem(id, "Machine 1", 1)
            tree.AppendItem(id, "Machine 2", 1)
            tree.AppendItem(id, "Machine 3", 1)
            tree.AppendItem(id, "Machine 4", 1)
            tree.AppendItem(id, "Machine 5", 1)
        
        tree.Expand(root)

        return tree

    

    def CreateHTMLCtrl(self,parent):
        ctrl = wx.html.HtmlWindow(parent, -1, wx.DefaultPosition, wx.Size(400, 300))
        if "gtk2" in wx.PlatformInfo or "gtk3" in wx.PlatformInfo:
            ctrl.SetStandardFonts()
        ctrl.SetPage(self.GetIntroText())        
        return ctrl
    
    
    def CreateSVGHTML(self,parent, file):
        with open (file, "r") as myfile:
            data=myfile.read().replace('\n', '')
        print data
        ctrl = wx.html.HtmlWindow(parent, -1, wx.DefaultPosition, wx.Size(400, 300))
        if "gtk2" in wx.PlatformInfo or "gtk3" in wx.PlatformInfo:
            ctrl.SetStandardFonts()
        data=lllmyfile.read(wx_svg.py)
        ctrl.SetPage(data)        
        return ctrl
    def GetIntroText(self):
        return overview

    def On_OpenSVG(self,evt):
        self.On_OpenFile(evt,wildcard)
        
    def On_OpenJob(self,evt):
        self.On_OpenFile(evt,wildcard1)
    
    
    def On_OpenFile(self, evt,wcard):
        

        dlg = wx.FileDialog(
            self, message="Choose a file",
            defaultDir=os.getcwd(), 
            defaultFile="*",
            wildcard=wcard,
            style=wx.OPEN | wx.CHANGE_DIR
            )

        # Show the dialog and retrieve the user response. If it is the OK response, 
        # process the data.
        if dlg.ShowModal() == wx.ID_OK:
            # This returns a Python list of files that were selected.
            self.filepaths = dlg.GetPaths()

            print('You selected file:'+ self.filepaths[0])

            svg_file = xml.dom.minidom.parse(self.filepaths[0])
            
            svg = svg_file.getElementsByTagName('svg')[0]
            
            raw_width = float(svg.getAttribute('width'))
            raw_height = float(svg.getAttribute('height'))

            
            if (not(self.xl,self.yl==None) and  raw_width>self.xl and raw_height>self.yl):
                print ("Please load an %x-%y SVG file " % self.xl, self.yl)
                #width_ratio = x and (x / raw_width) or 1
                #height_ratio = y and (y / raw_height) or 1

            pathCommands=[]
            elements = svg.getElementsByTagName('g')
            print ("Groups #"+str(elements.__len__()))
            for e in elements:
                paths = []
                if e.nodeName == 'g':
                    for path in e.getElementsByTagName('path'):
                        pathCommands = parse_path.get_path_commands(path.getAttribute('d'))
                        print (pathCommands)
                        for command in pathCommands:
                            print  (command)
            tabSVGPanel= wx.Panel(self.m_notebook1,-1,wx.DefaultPosition,wx.Size( 500,300 ),wx.TAB_TRAVERSAL)
        
            page=self.CreateSVGHTML(tabSVGPanel,self.filepaths[0])
        
            self.m_notebook1.AddPage(tabSVGPanel,"SVG", True,0)
        # Destroy the dialog. Don't do this until you are done with it!
        # BAD things can happen otherwise!
        dlg.Destroy()

overview = """\
<html><body>

<h1>wxGestalt</h1>

<p>A wxPython interface to the Gestalt system (<a href="http://mtm.cba.mit.edu/machines/science/">http://mtm.cba.mit.edu/machines/science/</a> + <a href="https://github.com/imoyer/gestalt">https://github.com/imoyer/gestalt</a>)</p>

<p>Source code on <a href="https://github.com/openp2pdesign/wxGestalt">https://github.com/openp2pdesign/wxGestalt</a></p>

</body></html>
"""


#---------------------------------------------------------------------------

# This is how you pre-establish a file filter so that the dialog
# only shows the extension(s) you want it to.
wildcard = "SVG File (*.svg)|*.svg|"    \
            "All files (*.*)|*.*"

wildcard1 = "XML File (*.xml)|*.xml|"    \
            "Text File (*.txt)|*.txt|"  \
            "All files (*.*)|*.*"

#---------------------------------------------------------------------------


if __name__ == '__main__':
    ex = wx.App()
    ex1 = PyAUIFrame(None)
    ex1.Show()
    ex.MainLoop()

