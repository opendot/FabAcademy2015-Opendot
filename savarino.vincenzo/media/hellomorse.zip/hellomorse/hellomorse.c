#include <avr/io.h>
#include <inttypes.h>
#include <util/delay.h>
#include <avr/pgmspace.h>

void delay_ms(uint16_t ms);
void init_io();
int button_is_pressed();


void morse_character(char c);
void morse_P(const char *s);
const unsigned char morse_code_table[];

#define F_CPU 20000000UL        /* 20MHz crystal oscillator */

#define BUTTON_PORT PORTA       /* PORTx - register for button output */
#define BUTTON_PIN PINA         /* PINx - register for button input */
#define BUTTON_BIT PA3          /* bit for button input/output */

#define LED_PORT PORTA          /* PORTx - register for LED output */
#define LED_BIT PA7             /* bit for button input/output */
#define LED_DDR DDRA            /* LED data direction register */

#define DEBOUNCE_TIME 25        /* time to wait while "de-bouncing" button */
#define LOCK_INPUT_TIME 250     /* time to wait after a button press */

#define DIT 25		            /* unit time for morse code */

int 
main (void)
{
        init_io();

        while (1)                       
        {
                if (button_is_pressed())
                {
                        
					   morse_P(PSTR("FAB ACADEMY"));
							   
                       
                }
        }
}

void delay_ms(uint16_t ms) {
        while ( ms )
        {
                _delay_ms(1);
                ms--;
        }
}

void 
init_io() 
{
        /* set LED pin as digital output */
        LED_DDR = _BV (LED_BIT); 

        /* led is OFF initially (set pin high) */         
        LED_PORT |= _BV(LED_BIT);

        /* turn on internal pull-up resistor for the switch */
        BUTTON_PORT |= _BV(BUTTON_BIT);
}

int 
button_is_pressed()
{
        /* the button is pressed when BUTTON_BIT is clear */
        if (bit_is_clear(BUTTON_PIN, BUTTON_BIT))
        {
                delay_ms(DEBOUNCE_TIME);
                if (bit_is_clear(BUTTON_PIN, BUTTON_BIT)) return 1;
        }

        return 0;
}



// blink a single character in Morse code
void morse_character(char c)
{
	unsigned char code, count;

	if (c == ' ') {
		
		delay_ms(DIT * 7);
		return;
	}
	
	
	
	/*if (c >= '0' && c <= '9') {
		
		code = pgm_read_byte(morse_code_table + (c = c - '0' + 27));
		
	}*/
	
	
	if(c >= 'A' && c <= 'Z') {
	
		code = pgm_read_byte(morse_code_table + (c - 'A'));
	
	}
	
	else {
		
		return;
	}
	
	for (count = code & 0x07; count > 0; count--) {
		LED_PORT=0b00000001;
		if (code & 0x80) {
			
			delay_ms(DIT * 3);
		} else {
			
			delay_ms(DIT);
		}
		LED_PORT=0b10000000;
		delay_ms(DIT);
		code = code << 1;
	}
	
	delay_ms(DIT * 2);
}

// blink an entire message in Morse code
// the string must be in flash memory (using PSTR macro)
void morse_P(const char *s)
{
	char c;
	
	while (1) {
		c = pgm_read_byte(s++);
		if (!c) break;
		morse_character(c);
	}
	
}

const unsigned char PROGMEM morse_code_table[] = {
	0x40 + 2,	// A: .-
	0x80 + 4,	// B: -...
	0xA0 + 4,	// C: -.-.
	0x80 + 3,	// D: -..
	0x00 + 1,	// E: .
	0x20 + 4,	// F: ..-.
	0xC0 + 3,	// G: --.
	0x00 + 4,	// H: ....
	0x00 + 2,	// I: ..
	0x70 + 4,	// J: .---
	0xA0 + 3,	// K: -.-
	0x40 + 4,	// L: .-..
	0xC0 + 2,	// M: --
	0x80 + 2,	// N: -.
	0xE0 + 3,	// O: ---
	0x60 + 4,	// P: .--.
	0xD0 + 4,	// Q: --.-
	0x40 + 3,	// R: .-.
	0x00 + 3,	// S: ...
	0x80 + 1,	// T: -
	0x20 + 3,	// U: ..-
	0x10 + 4,	// V: ...-
	0x60 + 3,	// W: .--
	0x90 + 4,	// X: -..-
	0xB0 + 4,	// Y: -.--
	0xC0 + 4    // Z: --..
	
};

