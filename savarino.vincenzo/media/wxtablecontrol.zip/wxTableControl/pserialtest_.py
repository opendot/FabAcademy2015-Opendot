'''
Created on 19/mag/2015

@author: SAVARINO
'''
# Import the library
import serial
from time import sleep



def ReadSerial():
# Try to connect to the port
    print "Connecting...."
    try:
        fabkit = serial.Serial('COM5', 9600)
    except:
        print "Failed to connect"
        exit()
    i=0;
    # Read data and print it to terminal... until you stop the program
    while i<10:
        line = fabkit.readline()
        print line
        
        fabkit.write('K')
        
        fabkit.write("#3F96")
       
        i=i+1
        sleep(1)
        


if __name__ == '__main__':
    ex = ReadSerial()
