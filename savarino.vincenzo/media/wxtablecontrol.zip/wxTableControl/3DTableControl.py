# -*- coding: utf-8 -*- 

###########################################################################
## Python code generated with wxFormBuilder (version Jun  5 2014)
## http://www.wxformbuilder.org/
##
## PLEASE DO "NOT" EDIT THIS FILE!
###########################################################################

import wx
import wx.xrc
import wx.aui
import wx.grid

###########################################################################
## Class ControlTable
###########################################################################

class ControlTable ( wx.Frame ):
	
	def __init__( self, parent ):
		wx.Frame.__init__ ( self, parent, id = wx.ID_ANY, title = u"3D Table Dashboard", pos = wx.DefaultPosition, size = wx.Size( 762,733 ), style = wx.DEFAULT_FRAME_STYLE|wx.TAB_TRAVERSAL )
		
		self.SetSizeHintsSz( wx.DefaultSize, wx.DefaultSize )
		self.m_mgr = wx.aui.AuiManager()
		self.m_mgr.SetManagedWindow( self )
		self.m_mgr.SetFlags(wx.aui.AUI_MGR_DEFAULT)
		
		self.m_menubar2 = wx.MenuBar( 0 )
		self.m_menu2 = wx.Menu()
		self.m_menuItem6 = wx.MenuItem( self.m_menu2, wx.ID_ANY, u"Open Frame", wx.EmptyString, wx.ITEM_NORMAL )
		self.m_menu2.AppendItem( self.m_menuItem6 )
		
		self.m_menuItem2 = wx.MenuItem( self.m_menu2, wx.ID_ANY, u"Open Stream", wx.EmptyString, wx.ITEM_NORMAL )
		self.m_menu2.AppendItem( self.m_menuItem2 )
		
		self.m_menu2.AppendSeparator()
		
		self.m_menuItem3 = wx.MenuItem( self.m_menu2, wx.ID_ANY, u"Exit", wx.EmptyString, wx.ITEM_NORMAL )
		self.m_menu2.AppendItem( self.m_menuItem3 )
		
		self.m_menubar2.Append( self.m_menu2, u"File" ) 
		
		self.m_menu3 = wx.Menu()
		self.m_menuItem4 = wx.MenuItem( self.m_menu3, wx.ID_ANY, u"About", wx.EmptyString, wx.ITEM_NORMAL )
		self.m_menu3.AppendItem( self.m_menuItem4 )
		
		self.m_menubar2.Append( self.m_menu3, u"Help" ) 
		
		self.SetMenuBar( self.m_menubar2 )
		
		self.m_statusBar2 = self.CreateStatusBar( 1, wx.ST_SIZEGRIP, wx.ID_ANY )
		self.m_panel1 = wx.Panel( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		self.m_mgr.AddPane( self.m_panel1, wx.aui.AuiPaneInfo() .Center() .CaptionVisible( False ).CloseButton( False ).PaneBorder( False ).Movable( False ).Dock().Resizable().FloatingSize( wx.DefaultSize ).DockFixed( False ) )
		
		gbSizer1 = wx.GridBagSizer( 0, 0 )
		gbSizer1.SetFlexibleDirection( wx.BOTH )
		gbSizer1.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )
		
		sbSizer1 = wx.StaticBoxSizer( wx.StaticBox( self.m_panel1, wx.ID_ANY, u"Serial Ports" ), wx.HORIZONTAL )
		
		bSizer1 = wx.BoxSizer( wx.VERTICAL )
		
		self.m_staticText1 = wx.StaticText( self.m_panel1, wx.ID_ANY, u"Servo", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText1.Wrap( -1 )
		bSizer1.Add( self.m_staticText1, 0, wx.ALL, 5 )
		
		m_choice4Choices = [ u"----" ]
		self.m_choice4 = wx.Choice( self.m_panel1, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, m_choice4Choices, 0 )
		self.m_choice4.SetSelection( 0 )
		bSizer1.Add( self.m_choice4, 0, wx.ALL, 5 )
		
		
		sbSizer1.Add( bSizer1, 1, wx.EXPAND, 5 )
		
		bSizer2 = wx.BoxSizer( wx.VERTICAL )
		
		self.m_staticText2 = wx.StaticText( self.m_panel1, wx.ID_ANY, u"Red", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText2.Wrap( -1 )
		bSizer2.Add( self.m_staticText2, 0, wx.ALL, 5 )
		
		m_choice5Choices = [ u"----", u"COM24" ]
		self.m_choice5 = wx.Choice( self.m_panel1, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, m_choice5Choices, 0 )
		self.m_choice5.SetSelection( 0 )
		bSizer2.Add( self.m_choice5, 0, wx.ALL, 5 )
		
		
		sbSizer1.Add( bSizer2, 1, wx.EXPAND, 5 )
		
		bSizer5 = wx.BoxSizer( wx.VERTICAL )
		
		self.m_staticText3 = wx.StaticText( self.m_panel1, wx.ID_ANY, u"Green", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText3.Wrap( -1 )
		bSizer5.Add( self.m_staticText3, 0, wx.ALL, 5 )
		
		m_choice3Choices = [ u"----", u"COM20" ]
		self.m_choice3 = wx.Choice( self.m_panel1, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, m_choice3Choices, 0 )
		self.m_choice3.SetSelection( 0 )
		bSizer5.Add( self.m_choice3, 0, wx.ALL, 5 )
		
		
		sbSizer1.Add( bSizer5, 1, wx.EXPAND, 5 )
		
		bSizer7 = wx.BoxSizer( wx.VERTICAL )
		
		self.m_staticText4 = wx.StaticText( self.m_panel1, wx.ID_ANY, u"Blue", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText4.Wrap( -1 )
		bSizer7.Add( self.m_staticText4, 0, wx.ALL, 5 )
		
		m_choice41Choices = [ u"----", u"COM18" ]
		self.m_choice41 = wx.Choice( self.m_panel1, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, m_choice41Choices, 0 )
		self.m_choice41.SetSelection( 0 )
		bSizer7.Add( self.m_choice41, 0, wx.ALL, 5 )
		
		
		sbSizer1.Add( bSizer7, 1, wx.EXPAND, 5 )
		
		
		gbSizer1.Add( sbSizer1, wx.GBPosition( 1, 0 ), wx.GBSpan( 1, 1 ), wx.EXPAND, 5 )
		
		sbSizer2 = wx.StaticBoxSizer( wx.StaticBox( self.m_panel1, wx.ID_ANY, u"RGB Color" ), wx.VERTICAL )
		
		self.m_slider4 = wx.Slider( self.m_panel1, wx.ID_ANY, 50, 0, 100, wx.DefaultPosition, wx.DefaultSize, wx.SL_HORIZONTAL )
		sbSizer2.Add( self.m_slider4, 0, wx.ALL, 5 )
		
		self.m_slider5 = wx.Slider( self.m_panel1, wx.ID_ANY, 50, 0, 100, wx.DefaultPosition, wx.DefaultSize, wx.SL_HORIZONTAL )
		sbSizer2.Add( self.m_slider5, 0, wx.ALL, 5 )
		
		self.m_slider6 = wx.Slider( self.m_panel1, wx.ID_ANY, 50, 0, 100, wx.DefaultPosition, wx.DefaultSize, wx.SL_HORIZONTAL )
		sbSizer2.Add( self.m_slider6, 0, wx.ALL, 5 )
		
		self.m_colourPicker2 = wx.ColourPickerCtrl( self.m_panel1, wx.ID_ANY, wx.Colour( 125, 125, 125 ), wx.DefaultPosition, wx.DefaultSize, wx.CLRP_DEFAULT_STYLE|wx.CLRP_SHOW_LABEL|wx.CLRP_USE_TEXTCTRL )
		sbSizer2.Add( self.m_colourPicker2, 0, wx.ALL, 5 )
		
		
		gbSizer1.Add( sbSizer2, wx.GBPosition( 2, 0 ), wx.GBSpan( 1, 1 ), wx.EXPAND, 5 )
		
		sbSizer3 = wx.StaticBoxSizer( wx.StaticBox( self.m_panel1, wx.ID_ANY, wx.EmptyString ), wx.HORIZONTAL )
		
		bSizer6 = wx.BoxSizer( wx.VERTICAL )
		
		self.m_staticText_pix_num = wx.StaticText( self.m_panel1, wx.ID_ANY, u"Pixel Number", wx.DefaultPosition, wx.DefaultSize, wx.ALIGN_CENTRE )
		self.m_staticText_pix_num.Wrap( -1 )
		bSizer6.Add( self.m_staticText_pix_num, 0, wx.ALL, 5 )
		
		self.m_textCtrl21 = wx.TextCtrl( self.m_panel1, wx.ID_ANY, u"1", wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer6.Add( self.m_textCtrl21, 0, wx.ALL, 5 )
		
		
		sbSizer3.Add( bSizer6, 1, wx.EXPAND, 5 )
		
		bSizer71 = wx.BoxSizer( wx.VERTICAL )
		
		self.m_staticText_frames = wx.StaticText( self.m_panel1, wx.ID_ANY, u"Frames (second)", wx.DefaultPosition, wx.DefaultSize, wx.ALIGN_CENTRE )
		self.m_staticText_frames.Wrap( -1 )
		bSizer71.Add( self.m_staticText_frames, 0, wx.ALL, 5 )
		
		m_choice51Choices = [ u"1", u"2", u"3", u"4", u"5", u"6", u"7", u"8", u"9" ]
		self.m_choice51 = wx.Choice( self.m_panel1, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, m_choice51Choices, 0 )
		self.m_choice51.SetSelection( 0 )
		bSizer71.Add( self.m_choice51, 0, wx.ALL, 5 )
		
		
		sbSizer3.Add( bSizer71, 1, wx.EXPAND, 5 )
		
		bSizer8 = wx.BoxSizer( wx.VERTICAL )
		
		
		sbSizer3.Add( bSizer8, 1, wx.EXPAND, 5 )
		
		
		gbSizer1.Add( sbSizer3, wx.GBPosition( 0, 0 ), wx.GBSpan( 1, 1 ), wx.EXPAND, 5 )
		
		sbSizer21 = wx.StaticBoxSizer( wx.StaticBox( self.m_panel1, wx.ID_ANY, u"Servo Position" ), wx.VERTICAL )
		
		self.m_slider41 = wx.Slider( self.m_panel1, wx.ID_ANY, 50, 0, 100, wx.DefaultPosition, wx.DefaultSize, wx.SL_HORIZONTAL )
		sbSizer21.Add( self.m_slider41, 0, wx.ALL, 5 )
		
		
		gbSizer1.Add( sbSizer21, wx.GBPosition( 4, 0 ), wx.GBSpan( 1, 1 ), wx.EXPAND, 5 )
		
		self.m_grid3 = wx.grid.Grid( self.m_panel1, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, 0 )
		
		# Grid
		self.m_grid3.CreateGrid( 8, 8 )
		self.m_grid3.EnableEditing( False )
		self.m_grid3.EnableGridLines( True )
		self.m_grid3.SetGridLineColour( wx.SystemSettings.GetColour( wx.SYS_COLOUR_WINDOWTEXT ) )
		self.m_grid3.EnableDragGridSize( False )
		self.m_grid3.SetMargins( 0, 0 )
		
		# Columns
		self.m_grid3.SetColSize( 0, 50 )
		self.m_grid3.SetColSize( 1, 50 )
		self.m_grid3.SetColSize( 2, 50 )
		self.m_grid3.SetColSize( 3, 50 )
		self.m_grid3.SetColSize( 4, 50 )
		self.m_grid3.SetColSize( 5, 50 )
		self.m_grid3.SetColSize( 6, 50 )
		self.m_grid3.SetColSize( 7, 50 )
		self.m_grid3.EnableDragColMove( False )
		self.m_grid3.EnableDragColSize( False )
		self.m_grid3.SetColLabelSize( 0 )
		self.m_grid3.SetColLabelAlignment( wx.ALIGN_CENTRE, wx.ALIGN_CENTRE )
		
		# Rows
		self.m_grid3.SetRowSize( 0, 50 )
		self.m_grid3.SetRowSize( 1, 50 )
		self.m_grid3.SetRowSize( 2, 50 )
		self.m_grid3.SetRowSize( 3, 50 )
		self.m_grid3.SetRowSize( 4, 50 )
		self.m_grid3.SetRowSize( 5, 50 )
		self.m_grid3.SetRowSize( 6, 50 )
		self.m_grid3.SetRowSize( 7, 50 )
		self.m_grid3.EnableDragRowSize( True )
		self.m_grid3.SetRowLabelSize( 0 )
		self.m_grid3.SetRowLabelAlignment( wx.ALIGN_CENTRE, wx.ALIGN_CENTRE )
		
		# Label Appearance
		
		# Cell Defaults
		self.m_grid3.SetDefaultCellBackgroundColour( wx.Colour( 255, 255, 255 ) )
		self.m_grid3.SetDefaultCellFont( wx.Font( wx.NORMAL_FONT.GetPointSize(), 70, 90, 90, False, wx.EmptyString ) )
		self.m_grid3.SetDefaultCellAlignment( wx.ALIGN_CENTRE, wx.ALIGN_CENTRE )
		gbSizer1.Add( self.m_grid3, wx.GBPosition( 1, 1 ), wx.GBSpan( 100, 1 ), wx.ALL, 10 )
		
		sbSizer5 = wx.StaticBoxSizer( wx.StaticBox( self.m_panel1, wx.ID_ANY, wx.EmptyString ), wx.VERTICAL )
		
		self.m_staticText7 = wx.StaticText( self.m_panel1, wx.ID_ANY, u"Pin Selected", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText7.Wrap( -1 )
		sbSizer5.Add( self.m_staticText7, 0, wx.ALL, 5 )
		
		self.m_staticText8 = wx.StaticText( self.m_panel1, wx.ID_ANY, u"0 (0,0)", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText8.Wrap( -1 )
		self.m_staticText8.SetFont( wx.Font( 18, 75, 90, 92, False, wx.EmptyString ) )
		
		sbSizer5.Add( self.m_staticText8, 0, wx.ALL, 5 )
		
		
		gbSizer1.Add( sbSizer5, wx.GBPosition( 0, 1 ), wx.GBSpan( 1, 1 ), wx.EXPAND, 5 )
		
		
		self.m_panel1.SetSizer( gbSizer1 )
		self.m_panel1.Layout()
		gbSizer1.Fit( self.m_panel1 )
		self.m_auiToolBar1 = wx.aui.AuiToolBar( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.aui.AUI_TB_HORZ_LAYOUT ) 
		self.m_tool1_serial_connect = self.m_auiToolBar1.AddTool( wx.ID_ANY, u"open-close serial port", wx.Bitmap( u"resource/close.png", wx.BITMAP_TYPE_ANY ), wx.NullBitmap, wx.ITEM_NORMAL, u"Open/Close serial port", u"Open/Close serial port", None ) 
		
		self.m_tool3_test = self.m_auiToolBar1.AddTool( wx.ID_ANY, u"Start Test", wx.Bitmap( u"resource/hide.png", wx.BITMAP_TYPE_ANY ), wx.NullBitmap, wx.ITEM_NORMAL, u"Start Test", u"Start Test", None ) 
		
		self.m_tool_3_ser_monitor = self.m_auiToolBar1.AddTool( wx.ID_ANY, u"Enable/Disable Debug", wx.Bitmap( u"resource/Tutorial.png", wx.BITMAP_TYPE_ANY ), wx.NullBitmap, wx.ITEM_NORMAL, u"Enable/Disable Debug", u"Enable/Disable Debug", None ) 
		
		self.m_tool4_all_red = self.m_auiToolBar1.AddTool( wx.ID_ANY, u"Make RED", wx.Bitmap( u"resource/ActionCenterRed.png", wx.BITMAP_TYPE_ANY ), wx.NullBitmap, wx.ITEM_NORMAL, u"Make RED", u"Make RED", None ) 
		
		self.m_tool5_all_green = self.m_auiToolBar1.AddTool( wx.ID_ANY, u"Make GREEN", wx.Bitmap( u"resource/ActionCenterGreen.png", wx.BITMAP_TYPE_ANY ), wx.NullBitmap, wx.ITEM_NORMAL, u"Make GREEN", u"Make GREEN", None ) 
		
		self.m_tool6_all_blue = self.m_auiToolBar1.AddTool( wx.ID_ANY, u"Make BLUE", wx.Bitmap( u"resource/ActionCenterBlue.png", wx.BITMAP_TYPE_ANY ), wx.NullBitmap, wx.ITEM_NORMAL, u"Make BLUE", u"Make BLUE", None ) 
		
		self.m_tool7_testservo = self.m_auiToolBar1.AddTool( wx.ID_ANY, u"Test SERVO", wx.Bitmap( u"resource/Up.png", wx.BITMAP_TYPE_ANY ), wx.NullBitmap, wx.ITEM_NORMAL, u"Test SERVO", u"Test SERVO", None ) 
		
		self.m_tool8_turn_led_off = self.m_auiToolBar1.AddTool( wx.ID_ANY, u"Turn LED OFF", wx.Bitmap( u"resource/ActionCenterGrey.png", wx.BITMAP_TYPE_ANY ), wx.NullBitmap, wx.ITEM_NORMAL, u"Turn LED OFF", u"Turn LED OFF", None ) 
		
		self.m_tool9_servo_down = self.m_auiToolBar1.AddTool( wx.ID_ANY, u"Turn SERVO DOWN", wx.Bitmap( u"resource/Stats_grey.png", wx.BITMAP_TYPE_ANY ), wx.NullBitmap, wx.ITEM_NORMAL, u"Turn SERVO DOWN", u"Turn SERVO DOWN", None ) 
		
		self.m_auiToolBar1.Realize()
		self.m_mgr.AddPane( self.m_auiToolBar1, wx.aui.AuiPaneInfo().Top().CaptionVisible( False ).CloseButton( False ).PaneBorder( False ).Movable( False ).Dock().Resizable().FloatingSize( wx.DefaultSize ).DockFixed( False ).BottomDockable( False ).TopDockable( False ).LeftDockable( False ).RightDockable( False ).Floatable( False ) )
		
		self.txtLog = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( -1,100 ), 0 )
		self.m_mgr.AddPane( self.txtLog, wx.aui.AuiPaneInfo() .Bottom() .CloseButton( False ).PinButton( True ).Dock().Resizable().FloatingSize( wx.DefaultSize ).DockFixed( False ) )
		
		
		self.m_mgr.Update()
		self.Centre( wx.BOTH )
		
		# Connect Events
		self.Bind( wx.EVT_MENU, self.OpenFrame, id = self.m_menuItem6.GetId() )
		self.Bind( wx.EVT_MENU, self.OpenStream, id = self.m_menuItem2.GetId() )
		self.Bind( wx.EVT_MENU, self.onExit, id = self.m_menuItem3.GetId() )
		self.Bind( wx.EVT_MENU, self.OnAbout, id = self.m_menuItem4.GetId() )
		self.m_choice4.Bind( wx.EVT_KEY_DOWN, self.pippo )
		self.m_grid3.Bind( wx.grid.EVT_GRID_CELL_LEFT_CLICK, self.onPinClick )
		self.Bind( wx.EVT_TOOL, self.Board_Connection, id = self.m_tool1_serial_connect.GetId() )
		self.Bind( wx.EVT_TOOL, self.Start_Test, id = self.m_tool3_test.GetId() )
		self.Bind( wx.EVT_TOOL, self.Serial_Monitor_Update, id = self.m_tool_3_ser_monitor.GetId() )
		self.Bind( wx.EVT_TOOL, self.TurnAllRed, id = self.m_tool4_all_red.GetId() )
		self.Bind( wx.EVT_TOOL, self.TurnAllGreen, id = self.m_tool5_all_green.GetId() )
		self.Bind( wx.EVT_TOOL, self.TurnAllBlue, id = self.m_tool6_all_blue.GetId() )
		self.Bind( wx.EVT_TOOL, self.TestServo, id = self.m_tool7_testservo.GetId() )
		self.Bind( wx.EVT_TOOL, self.TurnLedOff, id = self.m_tool8_turn_led_off.GetId() )
		self.Bind( wx.EVT_TOOL, self.TurnServoDown, id = self.m_tool9_servo_down.GetId() )
	
	def __del__( self ):
		self.m_mgr.UnInit()
		
	
	
	# Virtual event handlers, overide them in your derived class
	def OpenFrame( self, event ):
		event.Skip()
	
	def OpenStream( self, event ):
		event.Skip()
	
	def onExit( self, event ):
		event.Skip()
	
	def OnAbout( self, event ):
		event.Skip()
	
	def pippo( self, event ):
		event.Skip()
	
	def onPinClick( self, event ):
		event.Skip()
	
	def Board_Connection( self, event ):
		event.Skip()
	
	def Start_Test( self, event ):
		event.Skip()
	
	def Serial_Monitor_Update( self, event ):
		event.Skip()
	
	def TurnAllRed( self, event ):
		event.Skip()
	
	def TurnAllGreen( self, event ):
		event.Skip()
	
	def TurnAllBlue( self, event ):
		event.Skip()
	
	def TestServo( self, event ):
		event.Skip()
	
	def TurnLedOff( self, event ):
		event.Skip()
	
	def TurnServoDown( self, event ):
		event.Skip()
	

