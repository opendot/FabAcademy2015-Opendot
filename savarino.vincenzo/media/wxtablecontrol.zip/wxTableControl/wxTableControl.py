# -*- coding: utf-8 -*-

# Modules
# Modules for the wx GUI
import wx
import TableControlWindow

# Various functions
import wxFunctions
# Module for log
import sys

import time
import thread
import wx.lib.newevent
import serial
import random
import csv
 


# Variables
# Current global setting for the Serial port in use
SerialPortInUse = ""




# Classes
# Class for redirecting the terminal to the log screen
class RedirectText(object):
    # Redirect the print message to the Status log area
    def __init__(self,wxLog):
        self.out=wxLog

    def write(self,string):
        self.out.WriteText(string)


#----------------------------------------------------------------------

# This creates a new Event class and a EVT binder function
(UpdateBarEvent, EVT_UPDATE_SERIAL) = wx.lib.newevent.NewEvent()


#----------------------------------------------------------------------

class SerialThread:
    def __init__(self, win, port, val):
        self.win = win
        self.port = port
        self.val = val
        print "Connecting to...."+port
        try:
            self.fabkit = serial.Serial(port, 9600)
        except:
            print "waiting...."
            

    def Start(self):
        self.keepGoing = self.running = True
        thread.start_new_thread(self.Run, ())

    def Stop(self):
        self.keepGoing = False

    def IsRunning(self):
        return self.running

    def Run(self):
        while self.keepGoing:
            # We communicate with the UI by sending events to it. There can be
            # no manipulation of UI objects from the worker thread.
            
            
            evt = UpdateBarEvent(port = self.port, value = self.val)
            wx.PostEvent(self.win, evt)
 
            line = self.fabkit.readline()
            self.val=line

        self.running = False

#----------------------------------------------------------------------



#----------------------------------------------------------------------

class SerialFrame(wx.Frame):
    def __init__(self, parent):
        wx.Frame.__init__(self, parent, -1, "Thread Serial", size=(450,300))
        

        #self.CenterOnParent()

        panel = wx.Panel(self, -1)
        panel.SetFont(wx.Font(10, wx.SWISS, wx.NORMAL, wx.BOLD))
        
        
        #self.graph = GraphWindow(self, ['Zero', 'One', 'Two', 'Three', 'Four',
        #                                'Five', 'Six', 'Seven'])
        #self.graph.SetMinSize((450, self.graph.GetBestHeight()))
        
        self.console= wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( -1,300 ), wx.TE_MULTILINE|wx.TE_READONLY|wx.TE_WORDWRAP|wx.FULL_REPAINT_ON_RESIZE|wx.VSCROLL )
		

        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(panel, 0, wx.EXPAND)
        sizer.Add(self.console, 1, wx.EXPAND)

        self.SetSizer(sizer)
        self.SetAutoLayout(True)
        sizer.Fit(self)

        self.Bind(EVT_UPDATE_SERIAL, self.OnUpdate)

        self.threads = []
        print parent.serial_servo
        if (not(parent.serial_servo==None)):
            self.threads.append(SerialThread(self, parent.serial_servo, 0))
        if (not(parent.serial_red==None)):
            self.threads.append(SerialThread(self, parent.serial_red, 0))
        if (not(parent.serial_green==None)):    
            self.threads.append(SerialThread(self, parent.serial_servo, 0))
        if (not(parent.serial_blue==None)):    
            self.threads.append(SerialThread(self, parent.serial_servo, 0))
        

        for t in self.threads:
           
            t.Start()

        self.Bind(wx.EVT_CLOSE, self.OnCloseWindow)


    def OnUpdate(self, evt):
        self.console.AppendText("["+str(evt.port)+"]:"+ str(evt.value)+" \n")
        print str(evt.port)+" ->"+str(evt.value)
        self.console.Refresh(False)


    def OnCloseWindow(self, evt):
        busy = wx.BusyInfo("One moment please, waiting for threads to die...")
        wx.Yield()

        for t in self.threads:
            t.Stop()

        running = 1

        while running:
            running = 0

            for t in self.threads:
                running = running + t.IsRunning()

            time.sleep(0.1)

        self.Destroy()


# The class for the main app
class wxTableControl(TableControlWindow.ControlTable):
    
       
     
    
    def __init__(self, *args, **kw):
        super(wxTableControl, self).__init__(*args, **kw)
        self.pin_selected=1
        self.pin_selected_row=0
        self.pin_selected_col=0
        self.pin_pox=0
        self.pin_red=0
        self.pin_green=0
        self.pin_blue=0
        self.connected=False
        
        self.m_auiToolBar1.EnableTool(2, False )
        self.m_auiToolBar1.EnableTool(3, False )
        self.m_auiToolBar1.EnableTool(4, False )
        self.m_auiToolBar1.EnableTool(5, False )
        self.m_auiToolBar1.EnableTool(6, False )
        self.m_auiToolBar1.EnableTool(7, False )
        self.m_auiToolBar1.EnableTool(8, False )
        self.m_auiToolBar1.EnableTool(9, False )
        
        # servo port
        self.serial_servo=None
        # red port
        self.serial_red=None
        # green port
        self.serial_green=None
        # blue port
        self.serial_blue=None 
        
        self.InitUI()
        

    def InitUI(self):
        # Starting the log
        # Redirect text here
              
        redir=RedirectText(self.txtLog)
        
        sys.stdout=redir
        self.Show()
        print "Welcome"+'\n'
        
      

    def On_Quit( self, event ):
        self.Close(True)

    def On_ScanSerialPort( self, event ):
        # looks for available serial ports
        SerialPortsAvailable = wxFunctions.ScanSerialPorts()
        global SerialPortInUse
        # Global variable that can be accessed by the whole program
        dlg = wx.SingleChoiceDialog(self, 'Choose the serial port for your machine: ', 'Serial port settings', SerialPortsAvailable, wx.CHOICEDLG_STYLE)
        if dlg.ShowModal() == wx.ID_OK:
            SerialPortInUse = dlg.GetStringSelection()
            print "Connecting to",SerialPortInUse
             
        dlg.Destroy()

   
    def On_Message(self, title, content):
        # Open up a dialog
        dlg = wx.MessageDialog(self, content, title, wx.OK|wx.ICON_INFORMATION)
        dlg.ShowModal()
        dlg.Destroy()
    
    def onPinClick(self, event):
        TableControlWindow.ControlTable.onPinClick(self, event)
        print "Pin Selected: (%d,%d)" % (event.GetRow(), event.GetCol())
        self.pin_selected=(event.GetRow()*8+event.GetCol())+1
        self.pin_selected_row=event.GetRow()
        self.pin_selected_col=event.GetCol()
        self.color=self.m_colourPicker2.GetColour()
        self.m_grid3.SetCellBackgroundColour(event.GetRow(),event.GetCol(),self.color)
        self.m_grid3.Refresh()
        self.txtPinSelected.SetLabel(str((event.GetRow()*8+event.GetCol())+1)+"(%d,%d)" % (event.GetRow()+1, event.GetCol()+1))
        
    def OnChangeRed( self, event ):
        TableControlWindow.ControlTable.OnChangeRed(self, event)
        self.UpdateColor( self.m_slider4.GetValue(), self.m_slider5.GetValue(), self.m_slider6.GetValue() )
        
    
    def OnChangeGreen( self, event ):
        self.UpdateColor( self.m_slider4.GetValue(), self.m_slider5.GetValue(), self.m_slider6.GetValue() )
    
    def OnChangeBlue( self, event ):
        self.UpdateColor( self.m_slider4.GetValue(), self.m_slider5.GetValue(), self.m_slider6.GetValue() )
        
    def UpdateColor(self,r,g,b):
        self.m_colourPicker2.SetColour(wx.Colour( self.m_slider4.GetValue(), self.m_slider5.GetValue(), self.m_slider6.GetValue() ))
        list_of_tuples=self.m_grid3.GetSelectedCells()
        print list_of_tuples
        for (x,y) in list_of_tuples:
            print x,y
            self.m_grid3.SetCellBackgroundColour(x,y,wx.Colour( self.m_slider4.GetValue(), self.m_slider5.GetValue(), self.m_slider6.GetValue() ))
            self.m_grid3.Refresh()
        self.m_grid3.SetCellBackgroundColour(self.pin_selected_row,self.pin_selected_col,wx.Colour( self.m_slider4.GetValue(), self.m_slider5.GetValue(), self.m_slider6.GetValue() ))
        self.m_grid3.Refresh()

    def OnAbout(self, event ):
        TableControlWindow.ControlTable.OnAbout(self, event)
        print ""

    
           
        
    def onChangeColor(self, event):
        TableControlWindow.ControlTable.onChangeColor(self, event)
        color=self.m_colourPicker2.GetColour()
        self.m_slider4.SetValue(color.Red())
        self.m_slider5.SetValue(color.Green())
        self.m_slider6.SetValue(color.Blue())
        list_of_tuples=self.m_grid3.GetSelectedCells()
        print list_of_tuples
        for (x,y) in list_of_tuples:
            print x,y
            self.m_grid3.SetCellBackgroundColour(x,y,wx.Colour( self.m_slider4.GetValue(), self.m_slider5.GetValue(), self.m_slider6.GetValue() ))
            self.m_grid3.Refresh()
        self.m_grid3.SetCellBackgroundColour(self.pin_selected_row,self.pin_selected_col,wx.Colour( color.Red(), color.Green(), color.Blue()))
        self.m_grid3.Refresh()
        
    def updateServoSelectPorts(self, event):
        TableControlWindow.ControlTable.updateServoPorts(self, event)
        print wxFunctions.ScanSerialPorts()
        portlist=wxFunctions.ScanSerialPorts()
        portlist.append("----")
        self.m_choice4.Set(portlist)
        
        
    
    def updateRedSelectPorts(self, event):
        TableControlWindow.ControlTable.updateServoPorts(self, event)
        print wxFunctions.ScanSerialPorts()
        portlist=wxFunctions.ScanSerialPorts()
        portlist.append("----")
        self.m_choice5.Set(portlist)
        
        
    def updateGreenSelectPorts(self, event):
        TableControlWindow.ControlTable.updateServoPorts(self, event)
        print wxFunctions.ScanSerialPorts()
        portlist=wxFunctions.ScanSerialPorts()
        portlist.append("----")
        self.m_choice3.Set(portlist)
        
        
    def updateBlueSelectPorts(self, event):
        TableControlWindow.ControlTable.updateServoPorts(self, event)
        print wxFunctions.ScanSerialPorts()
        portlist=wxFunctions.ScanSerialPorts()
        portlist.append("----")
        self.m_choice41.Set(portlist)           
        
    def OpenSerialMonitor( self, event ):
        TableControlWindow.ControlTable.OpenSerialMonitor(self, event)
        print "port"
        print  self.m_choice4.GetString(self.m_choice4.GetCurrentSelection())      
        self.serial_servo=self.m_choice4.GetString(self.m_choice4.GetCurrentSelection());
        self.serial_red=self.m_choice5.GetString(self.m_choice5.GetSelection());
        self.serial_green=self.m_choice3.GetString(self.m_choice3.GetSelection());
        self.serial_blue=self.m_choice41.GetString(self.m_choice41.GetSelection());
        self.win = SerialFrame(self)
        self.win.Show(True)
    
    def Board_Connection(self, event):
        TableControlWindow.ControlTable.Board_Connection(self, event)
        if not self.connected:
            self.connected=True
            self.m_auiToolBar1.SetToolBitmap(1,wx.Bitmap( u"resource/open.png", wx.BITMAP_TYPE_ANY ))
            self.m_auiToolBar1.EnableTool(2, True )
            self.m_auiToolBar1.EnableTool(3, True )
            self.m_auiToolBar1.EnableTool(4, True )
            self.m_auiToolBar1.EnableTool(5, True )
            self.m_auiToolBar1.EnableTool(6, True )
            self.m_auiToolBar1.EnableTool(7, True )
            self.m_auiToolBar1.EnableTool(8, True )
            self.m_auiToolBar1.EnableTool(9, True )
        else:
            self.connected=False
            self.m_auiToolBar1.SetToolBitmap(1,wx.Bitmap( u"resource/close.png", wx.BITMAP_TYPE_ANY ))
            self.m_auiToolBar1.EnableTool(2, False )
            self.m_auiToolBar1.EnableTool(3, False )
            self.m_auiToolBar1.EnableTool(4, False )
            self.m_auiToolBar1.EnableTool(5, False )
            self.m_auiToolBar1.EnableTool(6, False )
            self.m_auiToolBar1.EnableTool(7, False )
            self.m_auiToolBar1.EnableTool(8, False )
            self.m_auiToolBar1.EnableTool(9, False )
            
        
            
if __name__ == '__main__':
    ex = wx.App()
    ex1 = wxTableControl(None)
    ex1.Show()
    ex.MainLoop()


