'''
Created on 22/giu/2015

@author: SAVARINO
'''
import csv
with open('file.csv', 'rb') as f:
    reader = csv.reader(f)
    your_list = list(reader)

print your_list



temp = []
for sub_list in your_list:
    temp.append(sub_list) 
print temp

