#ifndef Leds_h
#define Leds_h	

#if ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif
 	
class Leds
{	
 public:
   Leds(int led);
   Leds(int red, int green);
   void red();
   void green();
   void off();
   void led();
   void error();
   void dash(int pin);
   void dot(int pin);
	
 private:
   int _red;
   int _green;	
   int _led;	
};	
#endif
