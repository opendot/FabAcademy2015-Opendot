#if ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif
#include "Utils.h"	
 	
Utils::Utils()
{}	

int Utils::hex2Decimal(uint8_t hex)
{
  //if (hex >= '0' && hex <= '9') {return hex - '0'; }
  //else if (hex >= 'A' && hex <= 'F') { return hex - 'A' + 10; }

  if (hex >= 48 && hex <= 57) {return hex - 48; }
  else if (hex >= 65 && hex <= 70) { return hex - 65 + 10; }
}
