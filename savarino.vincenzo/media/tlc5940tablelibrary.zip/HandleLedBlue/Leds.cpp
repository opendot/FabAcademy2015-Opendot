//#include <wprogram.h>
#include "Leds.h"	
 	
Leds::Leds(int red,int green)
{
  if (red>2 && red<14){
    _red=red;
    pinMode(red,OUTPUT);
  }	
  if (green>2 && green<14){
    _green=green;
    pinMode(green,OUTPUT);
  }	
}	

Leds::Leds(int led)
{
  if (led>2 && led<14){
    _led=led;
    pinMode(led,OUTPUT);
  }	
}	
 	
void Leds::dot(int pin)	
{	
  digitalWrite(pin,HIGH);
  delay(250);
  digitalWrite(pin,LOW);
  delay(250);	
}	
 	
void Leds::dash(int pin)	
{
  digitalWrite(pin,HIGH);
  delay(1000);
  digitalWrite(pin,LOW);
  delay(250);	
}

void Leds::red()	
{
  digitalWrite(_red,HIGH);	
}	

void Leds::led()	
{
  digitalWrite(_led,HIGH);	
}	

void Leds::green()	
{
  digitalWrite(_green,HIGH);	
}	
 	
void Leds::off()	
{
  digitalWrite(_red,LOW); digitalWrite(_green,LOW); digitalWrite(_led,LOW);
}

void Leds::error()	
{
    if (_red>2 && _red<14){
      dot(_red); dash(_red); dot(_red);
    }
    else{
      dot(_green); dash(_green); dot(_green);
    }
}
