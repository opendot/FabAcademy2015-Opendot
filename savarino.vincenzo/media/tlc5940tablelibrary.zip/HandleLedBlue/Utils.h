#ifndef Utils_h
#define Utils_h	

#if ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif
#include <Wire.h>

class Utils
{
	
 public:
   Utils();
   int hex2Decimal(uint8_t hex);
   uint8_t devices();
	
 private:
  uint8_t device;
  uint8_t error;
  uint8_t addr;
};	
#endif
