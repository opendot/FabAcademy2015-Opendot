#include <avr/io.h>
#include <inttypes.h>
#include <util/delay.h>

void delay_ms(uint16_t ms);
void init_io();
int button_is_pressed();
void toggle_led();

#define F_CPU 20000000UL         /* 20MHz crystal oscillator */

#define BUTTON_PORT PORTA       /* PORTx - register for button output */
#define BUTTON_PIN PINA         /* PINx - register for button input */
#define BUTTON_BIT PA3          /* bit for button input/output */

#define LED_PORT PORTA          /* PORTx - register for LED output */
#define LED_BIT PA7             /* bit for button input/output */
#define LED_DDR DDRA            /* LED data direction register */

#define DEBOUNCE_TIME 25        /* time to wait while "de-bouncing" button */
#define LOCK_INPUT_TIME 250     /* time to wait after a button press */

int 
main (void)
{
        init_io();

        while (1)                       
        {
                if (button_is_pressed())
                {
                        toggle_led();
                       
                }
        }
}

void delay_ms(uint16_t ms) {
        while ( ms )
        {
                _delay_ms(1);
                ms--;
        }
}

void 
init_io() 
{
        /* set LED pin as digital output */
        LED_DDR = _BV (LED_BIT); 

        /* led is OFF initially (set pin high) */         
        LED_PORT |= _BV(LED_BIT);

        /* turn on internal pull-up resistor for the switch */
        BUTTON_PORT |= _BV(BUTTON_BIT);
}

int 
button_is_pressed()
{
        /* the button is pressed when BUTTON_BIT is clear */
        if (bit_is_clear(BUTTON_PIN, BUTTON_BIT))
        {
                delay_ms(DEBOUNCE_TIME);
                if (bit_is_clear(BUTTON_PIN, BUTTON_BIT)) return 1;
        }

        return 0;
}

void
toggle_led()
{
        LED_PORT ^= _BV(LED_BIT);
}
