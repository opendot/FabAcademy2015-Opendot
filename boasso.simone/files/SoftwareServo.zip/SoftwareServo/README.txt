http://playground.arduino.cc/ComponentLib/servo

Changes:
In SoftwareServo.h,   #include  <WProgram.h> 
 
was changed to,       #include "Arduino.h"

To accomodate the IDE 1.0+

Examples Added: Knob, Sweep