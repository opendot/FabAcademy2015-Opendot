3/26/2013

For ATtiny support, download the cores from https://code.google.com/p/arduino-tiny/
Tutorials can be found here: http://hlt.media.mit.edu/?p=1695


Note: -The ATtiny must be configured to run at 8MHz minimum.
